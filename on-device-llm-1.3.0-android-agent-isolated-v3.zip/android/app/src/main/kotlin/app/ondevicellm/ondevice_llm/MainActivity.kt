package app.ondevicellm.ondevice_llm

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.os.StatFs
import android.provider.DocumentsContract
import android.view.Display
import android.view.WindowManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private var projectFolderPicker: MethodChannel.Result? = null
    private val projectFolderPrefs by lazy { getSharedPreferences("project_folder", Context.MODE_PRIVATE) }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 7412) return
        val pending = projectFolderPicker ?: return
        projectFolderPicker = null
        if (resultCode != RESULT_OK || data?.data == null) {
            pending.success(null)
            return
        }
        val uri = data.data!!
        try {
            val requestedFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            val flags = data.flags and requestedFlags
            require((flags and requestedFlags) == requestedFlags) { "Android did not grant both read and write access to that folder." }
            contentResolver.takePersistableUriPermission(uri, flags)
            val root = DocumentFile.fromTreeUri(this, uri)
                ?: throw IllegalStateException("Could not open the selected folder.")
            require(root.exists() && root.isDirectory && root.canRead() && root.canWrite()) {
                "The selected folder does not provide read/write access."
            }
            // Commit the new selection only after its grant and capabilities
            // have been verified. A failed picker result must not replace the
            // previously working project folder with a broken URI.
            val previous = projectFolderPrefs.getString("tree_uri", null)
            projectFolderPrefs.edit().putString("tree_uri", uri.toString()).apply()
            if (previous != null && previous != uri.toString()) {
                try { contentResolver.releasePersistableUriPermission(Uri.parse(previous), Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) { }
            }
            pending.success(mapOf("uri" to uri.toString(), "name" to (root.name ?: "Project folder")))
        } catch (e: Exception) {
            // If validation failed after Android granted access, release only
            // this newly selected URI; keep any previous persisted selection.
            val previous = projectFolderPrefs.getString("tree_uri", null)
            if (previous != data.data.toString()) {
                try { contentResolver.releasePersistableUriPermission(data.data!!, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) { }
            }
            pending.error("FOLDER_PERMISSION", e.message, null)
        }
    }

    /**
     * The only root exposed to project tools is the exact SAF tree URI the
     * user selected. Never fall back to app storage, shared storage, or a
     * caller-provided URI/path when that grant is missing or revoked.
     */
    private fun projectRoot(): DocumentFile {
        val raw = projectFolderPrefs.getString("tree_uri", null)
            ?: throw IllegalStateException("Select a project folder first.")
        val treeUri = Uri.parse(raw)
        val grant = contentResolver.persistedUriPermissions.firstOrNull { it.uri == treeUri }
            ?: throw SecurityException("The selected project-folder permission is no longer granted. Select it again.")
        require(grant.isReadPermission && grant.isWritePermission) {
            "The selected folder must have both read and write access. Select it again."
        }
        val root = DocumentFile.fromTreeUri(this, treeUri)
            ?: throw IllegalStateException("The selected project folder is no longer available.")
        require(root.exists() && root.isDirectory && root.canRead() && root.canWrite()) {
            "The selected project folder is unavailable or does not allow read/write access."
        }
        return root
    }

    /** Strict relative paths only. No absolute paths, URI syntax, dot segments,
     * empty interior segments, backslash aliases, or control characters. */
    private fun safeSegments(path: String, allowRoot: Boolean = false): List<String> {
        if (path.isEmpty() && allowRoot) return emptyList()
        require(path.isNotEmpty()) { "A project-relative path is required." }
        require(!path.startsWith('/') && !path.startsWith('\\')) { "Absolute paths are not allowed." }
        require(!Regex("^[A-Za-z]:").containsMatchIn(path)) { "Drive-qualified paths are not allowed." }
        require(!path.contains("://") && !path.contains('\u0000')) { "URI and invalid paths are not allowed." }
        val parts = path.split('/')
        require(parts.none { it.isEmpty() || it == "." || it == ".." }) { "Invalid relative path." }
        parts.forEach { safeName(it) }
        return parts
    }

    private fun safeName(name: String): String {
        require(name.isNotBlank() && name != "." && name != "..") { "Invalid item name." }
        require(!name.contains('/') && !name.contains('\\') && !name.contains('\u0000')) {
            "An item name cannot contain path separators or NUL."
        }
        require(name.none { it.code < 32 || it.code == 127 }) { "Control characters are not allowed in item names." }
        return name
    }

    private fun projectDocument(path: String, createParents: Boolean = false): DocumentFile {
        var current = projectRoot()
        val parts = safeSegments(path)
        require(parts.isNotEmpty()) { "A file path is required." }
        for (part in parts.dropLast(1)) {
            var next = current.findFile(part)
            if (next == null && createParents) next = current.createDirectory(part)
            current = next ?: throw IllegalArgumentException("Folder not found: $part")
            require(current.isDirectory) { "Not a folder: $part" }
        }
        return current.findFile(parts.last()) ?: throw IllegalArgumentException("File not found: $path")
    }

    private fun projectParent(path: String, createParents: Boolean = false): Pair<DocumentFile, String> {
        val parts = safeSegments(path)
        require(parts.isNotEmpty()) { "A project-relative path is required." }
        var parent = projectRoot()
        for (part in parts.dropLast(1)) {
            var next = parent.findFile(part)
            if (next == null && createParents) next = parent.createDirectory(part)
            parent = next ?: throw IllegalArgumentException("Folder not found: $part")
            require(parent.isDirectory) { "Not a folder: $part" }
        }
        return parent to parts.last()
    }

    private fun deleteDocumentTree(document: DocumentFile) {
        if (document.isDirectory) {
            document.listFiles().forEach { child -> deleteDocumentTree(child) }
        }
        require(document.delete()) { "The document provider could not delete ${document.name ?: "the item"}." }
    }

    private fun copyDocumentTree(source: DocumentFile, targetParent: DocumentFile, targetName: String): DocumentFile {
        require(targetParent.findFile(targetName) == null) { "Destination already exists: $targetName" }
        if (source.isDirectory) {
            val target = targetParent.createDirectory(targetName)
                ?: throw IllegalStateException("Could not create destination folder: $targetName")
            try {
                source.listFiles().forEach { child ->
                    copyDocumentTree(child, target, child.name ?: "unnamed")
                }
                return target
            } catch (e: Exception) {
                try { deleteDocumentTree(target) } catch (_: Exception) { }
                throw e
            }
        }
        val target = targetParent.createFile(source.type ?: "application/octet-stream", targetName)
            ?: throw IllegalStateException("Could not create destination file: $targetName")
        try {
            val input = contentResolver.openInputStream(source.uri)
                ?: throw IllegalStateException("Could not read ${source.name ?: "source file"}.")
            val output = contentResolver.openOutputStream(target.uri, "wt")
                ?: throw IllegalStateException("Could not write $targetName.")
            input.use { src -> output.use { dst -> src.copyTo(dst) } }
            return target
        } catch (e: Exception) {
            try { target.delete() } catch (_: Exception) { }
            throw e
        }
    }

    private fun moveProjectDocument(sourcePath: String, destinationPath: String) {
        val sourceParts = safeSegments(sourcePath)
        val destinationParts = safeSegments(destinationPath)
        require(sourceParts.isNotEmpty() && destinationParts.isNotEmpty()) { "Source and destination paths are required." }
        sourceParts.forEach { safeName(it) }
        destinationParts.forEach { safeName(it) }
        require(sourceParts != destinationParts) { "Source and destination are identical." }
        val source = projectDocument(sourcePath)
        if (source.isDirectory) {
            require(destinationParts.size <= sourceParts.size || destinationParts.take(sourceParts.size) != sourceParts) {
                "A folder cannot be moved into itself or one of its descendants."
            }
        }
        val (sourceParent, _) = projectParent(sourcePath)
        val (destinationParent, destinationName) = projectParent(destinationPath, createParents = true)
        require(destinationParent.findFile(destinationName) == null) { "Destination already exists: $destinationPath" }
        if (sourceParent.uri == destinationParent.uri) {
            require(source.renameTo(destinationName)) { "The document provider could not rename/move this item." }
            return
        }
        // Prefer the provider's native move (fast and preserves metadata). Some
        // SAF providers do not implement moveDocument, so fall back to a
        // copy-then-delete operation that never removes the source on copy failure.
        val moved = try {
            DocumentsContract.moveDocument(
                contentResolver, source.uri, sourceParent.uri, destinationParent.uri
            )
        } catch (_: Exception) {
            null // Provider does not support native moves; use copy/delete below.
        }
        if (moved != null) {
            val movedDocument = DocumentFile.fromSingleUri(this, moved)
            if (movedDocument != null && movedDocument.name != destinationName) {
                require(movedDocument.renameTo(destinationName)) { "Moved item, but could not apply destination name." }
            }
            return
        }
        val copied = copyDocumentTree(source, destinationParent, destinationName)
        try {
            deleteDocumentTree(source)
        } catch (e: Exception) {
            // Keep the verified destination copy: rolling it back after a
            // partial source deletion could destroy the only remaining copy
            // of children already removed from the source tree.
            throw IllegalStateException("Copied to destination, but the original could not be fully removed. Both locations may now contain data; inspect them before retrying. ${e.message}")
        }
    }

    private var offlineDictation: OfflineDictation? = null
    private var shareInbox: ShareInbox? = null
    private var scheduledPrompts: ScheduledPrompts? = null
    private var hostDiscovery: HostDiscovery? = null
    private var voiceAudio: VoiceAudio? = null
    private var displayManager: DisplayManager? = null
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = refreshDisplay(displayId)
        override fun onDisplayRemoved(displayId: Int) = Unit
        override fun onDisplayChanged(displayId: Int) = refreshDisplay(displayId)
    }
    // Tags the models this window loads; they are freed when it is destroyed.
    private val nativeOwner = NativeBridge.newOwner()

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        shareInbox?.offer(intent, notify = true)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == OfflineDictation.PERMISSION_REQUEST) {
            offlineDictation?.onPermissionResult(
                grantResults.firstOrNull() == android.content.pm.PackageManager.PERMISSION_GRANTED)
        }
        if (requestCode == VoiceAudio.PERMISSION_REQUEST) {
            voiceAudio?.onPermissionResult(
                grantResults.firstOrNull() == android.content.pm.PackageManager.PERMISSION_GRANTED)
        }
        if (requestCode == ScheduledPrompts.PERMISSION_REQUEST) {
            scheduledPrompts?.onPermissionResult(
                grantResults.firstOrNull() == android.content.pm.PackageManager.PERMISSION_GRANTED)
        }
    }

    override fun onStop() {
        offlineDictation?.cancel()
        // Not seen any more: the conversation's microphone and voice stop
        // (audit C7); the screen listens again when it comes back.
        voiceAudio?.pause()
        super.onStop()
    }

    override fun onDestroy() {
        displayManager?.unregisterDisplayListener(displayListener)
        offlineDictation?.close()
        offlineDictation = null
        hostDiscovery?.close()
        hostDiscovery = null
        voiceAudio?.close()
        voiceAudio = null
        super.onDestroy()
        // The engine and its isolates are gone; the process and its native
        // memory may stay, so the model this window loaded is freed now.
        NativeBridge.release(nativeOwner)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayManager?.registerDisplayListener(displayListener, null)
        requestHighestRefreshRate()
    }

    override fun onResume() {
        super.onResume()
        // Some OEM power modes reset the preference while the app is backgrounded.
        requestHighestRefreshRate()
        window.decorView.post { requestHighestRefreshRate() }
    }

    private fun refreshDisplay(displayId: Int) {
        val active = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) display
            else @Suppress("DEPRECATION") windowManager.defaultDisplay
        if (displayId == active?.displayId) requestHighestRefreshRate()
    }

    /// Samsung (and other) phones keep a Flutter app at 60 Hz unless it asks
    /// for a display mode. Pick the fastest mode at the current resolution
    /// (120 Hz on the S25+); the framework then renders at that cadence.
    private fun requestHighestRefreshRate() {
        val display: Display = (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) display
            else @Suppress("DEPRECATION") windowManager.defaultDisplay) ?: return
        val current = display.mode
        val best = display.supportedModes
            .filter { it.physicalWidth == current.physicalWidth && it.physicalHeight == current.physicalHeight }
            .maxByOrNull { it.refreshRate } ?: return
        val attributes = window.attributes
        if (Build.VERSION.SDK_INT >= 35) window.setFrameRateBoostOnTouchEnabled(true)
        // A mode id is what the phone honours; a bare preferredRefreshRate was
        // not verified there.
        if (attributes.preferredDisplayModeId != best.modeId) {
            attributes.preferredDisplayModeId = best.modeId
            window.attributes = attributes
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        offlineDictation?.close()
        offlineDictation = OfflineDictation(this, flutterEngine.dartExecutor.binaryMessenger)
        shareInbox = ShareInbox(this, flutterEngine.dartExecutor.binaryMessenger).also {
            // The share that launched the app waits until Dart asks for it.
            it.offer(intent, notify = false)
        }
        scheduledPrompts = ScheduledPrompts(this, flutterEngine.dartExecutor.binaryMessenger)
        BackgroundDownloads(this, flutterEngine.dartExecutor.binaryMessenger)
        OnDeviceOcr(this, flutterEngine.dartExecutor.binaryMessenger)
        AudioDecode(flutterEngine.dartExecutor.binaryMessenger)
        PhoneActions(this, flutterEngine.dartExecutor.binaryMessenger)
        voiceAudio?.close()
        voiceAudio = VoiceAudio(this, flutterEngine.dartExecutor.binaryMessenger)
        hostDiscovery?.close()
        hostDiscovery = HostDiscovery(this, flutterEngine.dartExecutor.binaryMessenger)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ondevice_llm/project_folder")
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "pickFolder" -> {
                            if (projectFolderPicker != null) throw IllegalStateException("Folder picker is already open.")
                            projectFolderPicker = result
                            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                            }
                            startActivityForResult(intent, 7412)
                        }
                        "currentFolder" -> {
                            val raw = projectFolderPrefs.getString("tree_uri", null)
                            val root = raw?.let { DocumentFile.fromTreeUri(this, Uri.parse(it)) }
                            result.success(if (root == null || !root.exists()) null else mapOf("uri" to raw, "name" to (root.name ?: "Project folder")))
                        }
                        "list" -> {
                            val path = call.argument<String>("path") ?: ""
                            val parts = safeSegments(path, allowRoot = true)
                            var folder = projectRoot()
                            if (parts.isNotEmpty()) folder = projectDocument(path)
                            require(folder.isDirectory) { "Not a folder." }
                            result.success(folder.listFiles().take(2000).map { f -> mapOf("name" to (f.name ?: ""), "directory" to f.isDirectory, "size" to f.length(), "path" to listOf(path, f.name ?: "").filter { it.isNotBlank() }.joinToString("/")) })
                        }
                        "read" -> {
                            val file = projectDocument(call.argument<String>("path") ?: "")
                            require(file.isFile && (file.length() <= 1_000_000 || file.length() == 0L)) { "File is missing, not a file, or exceeds 1 MB." }
                            val input = contentResolver.openInputStream(file.uri)
                                ?: throw IllegalStateException("Unable to read file.")
                            val output = java.io.ByteArrayOutputStream()
                            input.use { stream ->
                                val buffer = ByteArray(8192)
                                var total = 0
                                while (true) {
                                    val count = stream.read(buffer)
                                    if (count < 0) break
                                    total += count
                                    require(total <= 1_000_000) { "File exceeds 1 MB." }
                                    output.write(buffer, 0, count)
                                }
                            }
                            // Do not silently turn binary or malformed UTF-8
                            // into replacement characters: the agent's read
                            // tool is explicitly text-only.
                            val decoded = Charsets.UTF_8.newDecoder()
                                .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                                .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
                                .decode(java.nio.ByteBuffer.wrap(output.toByteArray()))
                                .toString()
                            result.success(decoded)
                        }
                        "write" -> {
                            val path = call.argument<String>("path") ?: throw IllegalArgumentException("Missing path.")
                            val content = call.argument<String>("content") ?: ""
                            require(content.toByteArray(Charsets.UTF_8).size <= 1_000_000) { "File exceeds 1 MB." }
                            val parts = safeSegments(path)
                            require(parts.isNotEmpty())
                            safeName(parts.last())
                            var parent = projectRoot()
                            for (part in parts.dropLast(1)) {
                                parent = parent.findFile(part) ?: parent.createDirectory(part) ?: throw IllegalStateException("Cannot create folder.")
                                require(parent.isDirectory) { "A parent path is not a folder: $part" }
                            }
                            var file = parent.findFile(parts.last())
                            if (file == null) file = parent.createFile("application/octet-stream", parts.last())
                            val target = file ?: throw IllegalStateException("Cannot create file.")
                            contentResolver.openOutputStream(target.uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) }
                                ?: throw IllegalStateException("Unable to write file.")
                            result.success(true)
                        }
                        "mkdir" -> {
                            val parts = safeSegments(call.argument<String>("path") ?: "")
                            require(parts.isNotEmpty())
                            parts.forEach { safeName(it) }
                            var parent = projectRoot()
                            for (part in parts) {
                                parent = parent.findFile(part) ?: parent.createDirectory(part) ?: throw IllegalStateException("Cannot create folder.")
                                require(parent.isDirectory) { "A path already exists and is not a folder: $part" }
                            }
                            result.success(true)
                        }
                        "rename" -> {
                            val file = projectDocument(call.argument<String>("path") ?: "")
                            val name = safeName(call.argument<String>("name") ?: throw IllegalArgumentException("Missing new name."))
                            require(file.renameTo(name)) { "The document provider could not rename this item." }
                            result.success(true)
                        }
                        "move" -> {
                            moveProjectDocument(
                                call.argument<String>("sourcePath") ?: "",
                                call.argument<String>("destinationPath") ?: ""
                            )
                            result.success(true)
                        }
                        "delete" -> {
                            val path = call.argument<String>("path") ?: ""
                            val parts = safeSegments(path)
                            require(parts.isNotEmpty()) { "The project root cannot be deleted." }
                            val target = projectDocument(path)
                            deleteDocumentTree(target)
                            result.success(true)
                        }
                        "clearFolder" -> {
                            val previous = projectFolderPrefs.getString("tree_uri", null)
                            if (previous != null) {
                                try { contentResolver.releasePersistableUriPermission(Uri.parse(previous), Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) { }
                            }
                            projectFolderPrefs.edit().remove("tree_uri").apply()
                            result.success(true)
                        }
                        else -> result.notImplemented()
                    }
                } catch (e: Exception) {
                    result.error("PROJECT_FOLDER", e.message ?: "Project folder operation failed.", null)
                }
            }
        // Read-only device facts used to size models and defaults. Nothing leaves the device.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ondevice_llm/device")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "memoryInfo" -> {
                        val info = ActivityManager.MemoryInfo()
                        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(info)
                        result.success(
                            mapOf(
                                "totalBytes" to info.totalMem,
                                "availableBytes" to info.availMem,
                                "lowMemory" to info.lowMemory,
                            )
                        )
                    }
                    "storageInfo" -> {
                        val storage = StatFs((getExternalFilesDir(null) ?: filesDir).absolutePath)
                        result.success(mapOf(
                            "totalBytes" to storage.totalBytes,
                            "availableBytes" to storage.availableBytes,
                        ))
                    }
                    "refreshRate" -> {
                        val d = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) display
                            else @Suppress("DEPRECATION") windowManager.defaultDisplay
                        result.success(d?.refreshRate ?: 0f)
                    }
                    // Battery level/charging and the OS thermal status (0 none
                    // … 6 shutdown, -1 unknown) for the device-server page.
                    "powerInfo" -> {
                        val battery = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                        val thermal = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                            (getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus
                            else -1
                        result.success(mapOf(
                            "level" to battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY),
                            "charging" to battery.isCharging,
                            "thermalStatus" to thermal,
                        ))
                    }
                    // Which window the native runtimes belong to, and which
                    // bridge library Dart opened (NativeBridge frees them).
                    "nativeOwner" -> result.success(nativeOwner)
                    "nativeLibrary" -> {
                        (call.arguments as? String)?.let(NativeBridge::opened)
                        result.success(null)
                    }
                    // While this device serves a model the screen stays on, so
                    // the OS does not suspend the app mid-request.
                    "keepScreenOn" -> {
                        if (call.arguments == true) {
                            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        } else {
                            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        }
                        result.success(null)
                    }
                    else -> result.notImplemented()
                }
            }
    }
}
