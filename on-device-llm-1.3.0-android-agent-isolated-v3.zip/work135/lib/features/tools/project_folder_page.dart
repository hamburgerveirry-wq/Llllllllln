import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/design/app_design.dart';
import 'project_folder.dart';

class ProjectFolderPage extends ConsumerStatefulWidget {
  const ProjectFolderPage({super.key});
  @override
  ConsumerState<ProjectFolderPage> createState() => _ProjectFolderPageState();
}

class _ProjectFolderPageState extends ConsumerState<ProjectFolderPage> {
  List<Map<String, dynamic>> _entries = [];
  String? _error;
  bool _busy = false;
  String? _loadedUri;

  Future<void> _run(Future<void> Function() action) async {
    setState(() { _busy = true; _error = null; });
    try { await action(); } catch (e) { if (mounted) setState(() => _error = '$e'); }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _refresh(ProjectFolderService service) async {
    try {
      final items = await service.list('');
      if (mounted) setState(() { _entries = items; _error = null; _loadedUri = service.folder?['uri']; });
    } catch (e) { if (mounted) setState(() => _error = '$e'); }
  }

  @override
  Widget build(BuildContext context) {
    final service = ref.watch(projectFolderProvider);
    final folder = service.folder;
    if (folder != null && _loadedUri != folder['uri'] && _error == null && !_busy) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _refresh(service));
    }
    return Scaffold(
      appBar: AppBar(title: Text('Project folder'),),
      body: ListView(padding: const EdgeInsets.all(AppDesign.md), children: [
        Card(child: Padding(padding: const EdgeInsets.all(AppDesign.md), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(folder?['name'] ?? 'No project folder selected', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 6),
          Text(folder == null ? 'Choose a folder to let the agent read and edit files inside it.' : 'Project file tools are restricted to this selected folder. MCP tools are paused while it is connected, because an MCP server could otherwise access files outside this folder.'),
          const SizedBox(height: 12),
          Wrap(spacing: 8, children: [
            FilledButton.icon(onPressed: _busy ? null : () => _run(service.selectFolder), icon: const Icon(Icons.folder_open), label: const Text('Choose folder')),
            if (folder != null) OutlinedButton.icon(onPressed: _busy ? null : () => _run(service.clearFolder), icon: const Icon(Icons.link_off), label: const Text('Disconnect')),
            if (folder != null) OutlinedButton.icon(onPressed: _busy ? null : () => _refresh(service), icon: const Icon(Icons.refresh), label: const Text('Refresh')),
          ]),
        ]))),
        if (_busy) const LinearProgressIndicator(),
        if (_error != null) Padding(padding: const EdgeInsets.all(8), child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
        if (folder != null) ...[
          const SizedBox(height: 12),
          Text('Project root', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (_entries.isEmpty && !_busy) const Text('Folder is empty, or its contents could not be listed.'),
          for (final entry in _entries) ListTile(
            dense: true,
            leading: Icon(entry['directory'] == true ? Icons.folder_outlined : Icons.insert_drive_file_outlined),
            title: Text('${entry['name'] ?? ''}', maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: Text(entry['directory'] == true ? 'Folder' : '${entry['size'] ?? 0} bytes'),
          ),
        ],
        const SizedBox(height: 16),
        const Text('The local agent can list, read, create, edit, rename, move, and permanently delete files and folders inside this folder only. Android enforces access through the selected Storage Access Framework tree grant; absolute paths, URI paths, and parent-directory traversal are rejected. The project root cannot be renamed or deleted by agent tools. MCP tools are hidden while this folder is connected. Disconnect this folder to use MCP. Enable Settings > Tools > Let the model call tools so local models receive these tools. Arbitrary shell/code execution is not enabled.'),
      ]),
    );
  }
}
