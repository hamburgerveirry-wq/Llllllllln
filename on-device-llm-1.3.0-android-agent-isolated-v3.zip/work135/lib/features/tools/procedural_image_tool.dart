import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

import '../../core/storage/app_directories.dart';
import '../attachments/domain/attachment.dart';
import 'domain/tool_spec.dart';

/// Bounded, offline raster renderer for model-authored scene descriptions.
/// It deliberately accepts data, never executable model-generated code.
class ProceduralImageTool {
  /// Strict 480p output cap: 854×480 landscape or 480×854 portrait.
  static const maxLongSide = 854;
  static const maxShortSide = 480;
  static const maxPixels = maxLongSide * maxShortSide;
  static const maxElements = 160;

  static const spec = ToolSpec(
    name: 'generate_image',
    description: 'Generate an actual downloadable PNG image for the user. Use this tool when the user asks you to create, draw, illustrate, design, or generate an image; do not merely describe how to make it. This is a lightweight procedural renderer: create a detailed composition from layered rectangles, circles, ellipses, lines, and polygons with hex colors. It is best for illustrations, icons, pixel art, stylized scenes, diagrams, patterns, and graphic designs; it is not a diffusion or photorealistic photo model. Make thoughtful visual decisions yourself. Provide a concise title, canvas dimensions, a background color, optional vertical gradient colors, and ordered drawing elements. Coordinates are normalized 0–1 relative to the canvas. Use enough layered elements to make the requested image complete. Every shape supports color; lines support width; rectangles/ellipses/circles may be outlined or filled; polygons use normalized points. Never put executable code, URLs, or file paths in the scene.',
    parameters: {
      'type': 'object',
      'properties': {
        'title': {'type': 'string', 'description': 'Short descriptive filename/title.'},
        'width': {'type': 'integer', 'description': 'Canvas width in pixels. Strict 480p maximum: 854 landscape or 480 portrait. Default 854.'},
        'height': {'type': 'integer', 'description': 'Canvas height in pixels. Strict 480p maximum: 480 landscape or 854 portrait. Default 480.'},
        'background': {'type': 'string', 'description': 'Background hex color, e.g. #18243A.'},
        'gradient_bottom': {'type': 'string', 'description': 'Optional bottom color for a vertical background gradient.'},
        'elements': {
          'type': 'array',
          'description': 'Ordered drawing instructions, maximum 160. Coordinates and dimensions are normalized 0–1.',
          'items': {
            'type': 'object',
            'properties': {
              'shape': {'type': 'string', 'enum': ['rect', 'circle', 'ellipse', 'line', 'polygon']},
              'x': {'type': 'number'}, 'y': {'type': 'number'},
              'w': {'type': 'number'}, 'h': {'type': 'number'},
              'r': {'type': 'number'},
              'color': {'type': 'string'},
              'stroke': {'type': 'string'},
              'stroke_width': {'type': 'number'},
              'filled': {'type': 'boolean'},
              'points': {'type': 'array', 'items': {'type': 'array', 'items': {'type': 'number'}}},
            },
            'required': ['shape', 'color'],
          },
        },
      },
      'required': ['elements'],
    },
  );

  static bool wanted(String input) {
    final s = input.toLowerCase();
    if (RegExp(r'^\s*(?:how do i|how can i|how to|why|what is|what are)\b').hasMatch(s)) {
      return false;
    }
    return RegExp(r'\b(?:generate|create|make|draw|design|illustrate|paint)\b.{0,55}\b(?:image|picture|illustration|artwork|wallpaper|logo|icon|poster|drawing|graphic|diagram|map|scene|character|sprite|concept art|pixel art|mockup)\b|\b(?:image|picture|illustration|artwork|wallpaper|logo|icon|poster|drawing|diagram|map|scene|character|sprite|pixel art|mockup)\b.{0,45}\b(?:generate|create|make|draw|design)\b|\b(?:draw|paint|illustrate)\s+(?:me\s+)?(?:a|an|the)?\s*[a-z]|\b(?:i want|i need|i would like|give me)\b.{0,45}\b(?:image|picture|illustration|artwork|wallpaper|logo|icon|poster|drawing|graphic)\b')
        .hasMatch(s);
  }

  static Future<({String output, Attachment attachment})> generate(
    Map<String, dynamic> args,
  ) async {
    final width = _dimension(args['width'], 854);
    final height = _dimension(args['height'], 480);
    if (math.max(width, height) > maxLongSide ||
        math.min(width, height) > maxShortSide ||
        width * height > maxPixels) {
      throw const FormatException(
        'Image output is limited to 480p: maximum 854×480 landscape or 480×854 portrait.',
      );
    }
    final rawElements = args['elements'];
    if (rawElements is! List || rawElements.isEmpty || rawElements.length > maxElements) {
      throw const FormatException('Provide between 1 and 160 drawing elements.');
    }
    final png = await compute(_renderPng, <String, dynamic>{
      'width': width,
      'height': height,
      'background': args['background'] ?? '#20283A',
      'gradient_bottom': args['gradient_bottom'],
      'elements': rawElements,
    });
    final base = await appDataDirectory();
    final directory = Directory(p.join(base.path, 'attachments'));
    if (!await directory.exists()) await directory.create(recursive: true);
    final id = const Uuid().v4();
    final title = _safeName(args['title']?.toString() ?? 'generated-image');
    final file = File(p.join(directory.path, '$id.png'));
    await file.writeAsBytes(png, flush: true);
    final attachment = Attachment(
      id: id,
      kind: AttachmentKind.image,
      name: '$title.png',
      mime: 'image/png',
      path: file.path,
      sizeBytes: png.length,
    );
    return (
      output: 'Generated ${width}×$height PNG image: ${attachment.name}. The image is attached to the assistant response and can be saved from its download control.',
      attachment: attachment,
    );
  }

  static int _dimension(Object? value, int fallback) {
    final n = value is num ? value.toInt() : fallback;
    if (n < 128 || n > maxLongSide) {
      throw const FormatException(
        'Each image dimension must be between 128 and 854 pixels, with a strict 480p aspect limit.',
      );
    }
    return n;
  }

  static String _safeName(String value) {
    final cleaned = value.trim().replaceAll(RegExp(r'[^a-zA-Z0-9 _-]'), '').replaceAll(RegExp(r'\s+'), '-');
    final safe = cleaned.isEmpty ? 'generated-image' : cleaned;
    return safe.substring(0, safe.length > 64 ? 64 : safe.length);
  }

  static int _color(Object? value) {
    final s = (value ?? '#FFFFFF').toString().replaceFirst('#', '');
    if (!RegExp(r'^[0-9a-fA-F]{6}$').hasMatch(s)) throw const FormatException('Colors must be six-digit hex values such as #AABBCC.');
    return int.parse(s, radix: 16);
  }
}

Uint8List _renderPng(Map<String, dynamic> args) {
  final width = (args['width'] as num).toInt();
  final height = (args['height'] as num).toInt();
  final raster = _Raster(width, height);
  raster.gradient(
    ProceduralImageTool._color(args['background']),
    args['gradient_bottom'] == null
        ? null
        : ProceduralImageTool._color(args['gradient_bottom']),
  );
  final elements = args['elements'] as List;
  for (final raw in elements) {
    if (raw is! Map) continue;
    raster.draw(Map<String, dynamic>.from(raw));
  }
  return _Png.encode(width, height, raster.pixels);
}

class _Raster {
  final int width, height;
  late final Uint8List pixels = Uint8List(width * height * 4);
  _Raster(this.width, this.height);

  void gradient(int top, int? bottom) {
    final b = bottom ?? top;
    for (var y = 0; y < height; y++) {
      final t = height <= 1 ? 0.0 : y / (height - 1);
      final r = _mix((top >> 16) & 255, (b >> 16) & 255, t);
      final g = _mix((top >> 8) & 255, (b >> 8) & 255, t);
      final bl = _mix(top & 255, b & 255, t);
      for (var x = 0; x < width; x++) _put(x, y, (r << 16) | (g << 8) | bl);
    }
  }

  void draw(Map<String, dynamic> e) {
    final shape = e['shape']?.toString();
    final color = ProceduralImageTool._color(e['color']);
    final x = _coord(e['x']);
    final y = _coord(e['y'], vertical: true);
    final w = _size(e['w']);
    final h = _size(e['h'], vertical: true);
    final stroke = e['stroke'] == null ? null : ProceduralImageTool._color(e['stroke']);
    final sw = ((e['stroke_width'] as num?)?.toDouble() ?? 1.0).clamp(1.0, 32.0).round();
    final filled = e['filled'] != false;
    switch (shape) {
      case 'rect':
        if (filled) _rect(x, y, x + w, y + h, color);
        if (stroke != null) {
          for (var i = 0; i < sw; i++) {
            _line(x + i, y + i, x + w - i, y + i, stroke);
            _line(x + i, y + h - i, x + w - i, y + h - i, stroke);
            _line(x + i, y + i, x + i, y + h - i, stroke);
            _line(x + w - i, y + i, x + w - i, y + h - i, stroke);
          }
        }
        break;
      case 'circle':
        final r = _px((e['r'] as num?)?.toDouble() ?? 0.05);
        _circle(x, y, r, color, filled);
        if (stroke != null) _circle(x, y, r, stroke, false, thickness: sw);
        break;
      case 'ellipse':
        _ellipse(x, y, w, h, color, filled);
        if (stroke != null) _ellipse(x, y, w, h, stroke, false, thickness: sw);
        break;
      case 'line':
        _line(x, y, x + w, y + h, color, thickness: sw);
        break;
      case 'polygon':
        final points = e['points'];
        if (points is List && points.length >= 3 && points.length <= 64) {
          final pts = <(int, int)>[];
          for (final point in points) {
            if (point is List && point.length >= 2 && point[0] is num && point[1] is num) {
              pts.add((_coord(point[0]), _coord(point[1], vertical: true)));
            }
          }
          if (pts.length >= 3) {
            _polygon(pts, color, filled);
            if (stroke != null) {
              for (var i = 0; i < pts.length; i++) {
                final a = pts[i], b = pts[(i + 1) % pts.length];
                _line(a.$1, a.$2, b.$1, b.$2, stroke, thickness: sw);
              }
            }
          }
        }
        break;
    }
  }

  int _coord(Object? v, {bool vertical = false}) => (((v as num?)?.toDouble() ?? 0).clamp(0.0, 1.0) * ((vertical ? height : width) - 1)).round();
  int _size(Object? v, {bool vertical = false}) => (((v as num?)?.toDouble() ?? 0).clamp(0.0, 1.0) * (vertical ? height : width)).round();
  int _px(double v) => (v.clamp(0.0, 1.0) * math.min(width, height)).round();
  static int _mix(int a, int b, double t) => (a + (b - a) * t).round().clamp(0, 255).toInt();

  void _put(int x, int y, int c) {
    if (x < 0 || y < 0 || x >= width || y >= height) return;
    final i = (y * width + x) * 4;
    pixels[i] = (c >> 16) & 255;
    pixels[i + 1] = (c >> 8) & 255;
    pixels[i + 2] = c & 255;
    pixels[i + 3] = 255;
  }

  void _rect(int x1, int y1, int x2, int y2, int c) {
    final l = math.min(x1, x2).clamp(0, width - 1).toInt(), r = math.max(x1, x2).clamp(0, width - 1).toInt();
    final t = math.min(y1, y2).clamp(0, height - 1).toInt(), b = math.max(y1, y2).clamp(0, height - 1).toInt();
    for (var y = t; y <= b; y++) {
      for (var x = l; x <= r; x++) _put(x, y, c);
    }
  }

  void _line(int x0, int y0, int x1, int y1, int c, {int thickness = 1}) {
    var dx = (x1 - x0).abs(), sx = x0 < x1 ? 1 : -1;
    var dy = -(y1 - y0).abs(), sy = y0 < y1 ? 1 : -1;
    var err = dx + dy;
    while (true) {
      if (thickness == 1) { _put(x0, y0, c); } else { _circle(x0, y0, (thickness / 2).round(), c, true); }
      if (x0 == x1 && y0 == y1) break;
      final e2 = 2 * err;
      if (e2 >= dy) { err += dy; x0 += sx; }
      if (e2 <= dx) { err += dx; y0 += sy; }
    }
  }

  void _circle(int cx, int cy, int r, int c, bool filled, {int thickness = 1}) {
    final rr = r * r, inner = math.max(0, r - thickness) * math.max(0, r - thickness);
    for (var y = math.max(0, cy - r).toInt(); y <= math.min(height - 1, cy + r).toInt(); y++) {
      for (var x = math.max(0, cx - r).toInt(); x <= math.min(width - 1, cx + r).toInt(); x++) {
        final d = (x - cx) * (x - cx) + (y - cy) * (y - cy);
        if (filled ? d <= rr : d <= rr && d >= inner) _put(x, y, c);
      }
    }
  }

  void _ellipse(int cx, int cy, int rx, int ry, int c, bool filled, {int thickness = 1}) {
    rx = math.max(1, rx ~/ 2).toInt(); ry = math.max(1, ry ~/ 2).toInt();
    for (var y = math.max(0, cy - ry).toInt(); y <= math.min(height - 1, cy + ry).toInt(); y++) {
      for (var x = math.max(0, cx - rx).toInt(); x <= math.min(width - 1, cx + rx).toInt(); x++) {
        final d = math.pow((x - cx) / rx, 2) + math.pow((y - cy) / ry, 2);
        if (filled ? d <= 1 : d <= 1 && d >= math.pow(math.max(0, rx - thickness) / rx, 2)) _put(x, y, c);
      }
    }
  }

  void _polygon(List<(int, int)> points, int color, bool filled) {
    if (!filled) {
      for (var i = 0; i < points.length; i++) {
        final a = points[i], b = points[(i + 1) % points.length];
        _line(a.$1, a.$2, b.$1, b.$2, color);
      }
      return;
    }
    final minY = points.map((p) => p.$2).reduce((a, b) => a < b ? a : b).clamp(0, height - 1).toInt();
    final maxY = points.map((p) => p.$2).reduce((a, b) => a > b ? a : b).clamp(0, height - 1).toInt();
    for (var y = minY; y <= maxY; y++) {
      final nodes = <int>[];
      for (var i = 0, j = points.length - 1; i < points.length; j = i++) {
        final a = points[i], b = points[j];
        if ((a.$2 < y && b.$2 >= y) || (b.$2 < y && a.$2 >= y)) {
          nodes.add(a.$1 + ((y - a.$2) * (b.$1 - a.$1) / (b.$2 - a.$2)).round());
        }
      }
      nodes.sort();
      for (var i = 0; i + 1 < nodes.length; i += 2) {
        for (var x = nodes[i].clamp(0, width - 1).toInt(); x <= nodes[i + 1].clamp(0, width - 1).toInt(); x++) _put(x, y, color);
      }
    }
  }
}

class _Png {
  static Uint8List encode(int width, int height, Uint8List rgba) {
    final raw = BytesBuilder(copy: false);
    for (var y = 0; y < height; y++) {
      raw.addByte(0); // PNG filter: None
      raw.add(rgba.sublist(y * width * 4, (y + 1) * width * 4));
    }
    final out = BytesBuilder(copy: false)..add([137, 80, 78, 71, 13, 10, 26, 10]);
    final ihdr = ByteData(13)
      ..setUint32(0, width)
      ..setUint32(4, height)
      ..setUint8(8, 8)
      ..setUint8(9, 6)
      ..setUint8(10, 0)
      ..setUint8(11, 0)
      ..setUint8(12, 0);
    _chunk(out, 'IHDR', ihdr.buffer.asUint8List());
    _chunk(out, 'IDAT', Uint8List.fromList(ZLibEncoder(level: 6).convert(raw.takeBytes())));
    _chunk(out, 'IEND', Uint8List(0));
    return out.takeBytes();
  }

  static void _chunk(BytesBuilder out, String name, Uint8List data) {
    final type = ascii.encode(name);
    final length = ByteData(4)..setUint32(0, data.length);
    out.add(length.buffer.asUint8List());
    out.add(type);
    out.add(data);
    final crcInput = Uint8List(type.length + data.length)..setRange(0, type.length, type)..setRange(type.length, type.length + data.length, data);
    final crc = _crc32(crcInput);
    final checksum = ByteData(4)..setUint32(0, crc);
    out.add(checksum.buffer.asUint8List());
  }

  static int _crc32(Uint8List data) {
    var crc = 0xffffffff;
    for (final byte in data) {
      crc ^= byte;
      for (var i = 0; i < 8; i++) crc = (crc & 1) != 0 ? (crc >> 1) ^ 0xedb88320 : crc >> 1;
    }
    return (crc ^ 0xffffffff) & 0xffffffff;
  }
}
