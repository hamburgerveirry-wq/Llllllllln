import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart' show ChangeNotifierProvider;

import '../attachments/data/attachment_store.dart';
import '../attachments/domain/attachment.dart';
import 'domain/tool_spec.dart';

/// Android Storage Access Framework bridge. All paths are relative to the
/// persisted tree URI; no raw filesystem path is exposed to the model.
class ProjectFolderService extends ChangeNotifier {
  /// Action requests against the selected project should not be left to a
  /// model's optional tool choice. This deliberately excludes how-to questions
  /// so asking how to manage files does not trigger a filesystem operation.
  static bool requiresToolForRequest(String input) {
    final text = input.trim();
    final howTo = RegExp(
      r'\bhow\s+(?:do|can)\s+i\b|\bhow\s+to\b|\bshow\s+me\s+how\b|\bexplain\s+how\b',
      caseSensitive: false,
    );
    if (text.isEmpty || howTo.hasMatch(text)) return false;
    final mentionsProject = RegExp(
      r'\b(project|selected folder|project folder|workspace|repository|repo)\b',
      caseSensitive: false,
    ).hasMatch(text);
    final action = RegExp(
      r'\b(list|show|check|inspect|browse|find|search|read|open|view|create|make|write|save|edit|modify|update|rename|move|attach|download|send|delete|remove)\b',
      caseSensitive: false,
    ).hasMatch(text);
    final fileTarget = RegExp(
      r'\b(files?|folders?|directories|source|code|contents?|project|repository|repo)\b',
      caseSensitive: false,
    ).hasMatch(text);
    final filePath = RegExp(
      r'\b[\w./-]+\.(?:txt|md|dart|py|js|ts|json|ya?ml|toml|rs|cpp|h|java|kt|xml|html|css|gradle|sh|ps1)\b',
      caseSensitive: false,
    ).hasMatch(text);
    final toolCheck = RegExp(
          r'\b(check|inspect|test|verify|list|show)\b',
          caseSensitive: false,
        ).hasMatch(text) &&
        RegExp(r'\b(tools?|functions?|mcp)\b', caseSensitive: false)
            .hasMatch(text) &&
        !RegExp(r'\b(examples?|syntax|instructions)\b', caseSensitive: false)
            .hasMatch(text);
    return toolCheck || (action && (mentionsProject || fileTarget || filePath));
  }

  static const _channel = MethodChannel('ondevice_llm/project_folder');
  Map<String, String>? _folder;
  bool _loading = false;
  Future<void>? _loadFuture;
  Map<String, String>? get folder => _folder;
  bool get isSelected => _folder != null;
  bool get loading => _loading;

  Future<void> load() {
    final pending = _loadFuture;
    if (pending != null) return pending;
    _loading = true;
    final future = _loadInternal();
    _loadFuture = future;
    return future;
  }

  Future<void> _loadInternal() async {
    try {
      final value = await _channel.invokeMapMethod<String, dynamic>('currentFolder');
      _folder = value == null ? null : {'uri': '${value['uri']}', 'name': '${value['name']}'};
    } catch (_) {
      _folder = null;
    } finally {
      _loading = false;
      _loadFuture = null;
      notifyListeners();
    }
  }

  Future<void> selectFolder() async {
    final value = await _channel.invokeMapMethod<String, dynamic>('pickFolder');
    if (value != null) {
      _folder = {'uri': '${value['uri']}', 'name': '${value['name']}'};
      notifyListeners();
    }
  }

  Future<void> clearFolder() async {
    await _channel.invokeMethod<bool>('clearFolder');
    _folder = null;
    notifyListeners();
  }

  // Client-side validation improves error messages. The Android SAF bridge
  // repeats these checks and is the authoritative security boundary.
  List<String> _segments(String path, {bool allowRoot = false}) {
    if (path.isEmpty && allowRoot) return const [];
    if (path.isEmpty || path.startsWith('/') || path.startsWith('\\') ||
        RegExp(r'^[A-Za-z]:').hasMatch(path) || path.contains('\\') ||
        path.contains('://') || path.contains('\u0000')) {
      throw const FormatException('Only project-relative paths are allowed.');
    }
    final parts = path.split('/');
    if (parts.any((part) => part.isEmpty || part == '.' || part == '..' ||
        part.runes.any((rune) => rune < 32 || rune == 127))) {
      throw const FormatException('Invalid project-relative path.');
    }
    return parts;
  }

  String _safeName(String name) {
    if (name.trim().isEmpty || name == '.' || name == '..' ||
        name.contains('/') || name.contains('\\') || name.contains('\u0000') ||
        name.runes.any((rune) => rune < 32 || rune == 127)) {
      throw const FormatException('Invalid project item name.');
    }
    return name;
  }

  Future<List<Map<String, dynamic>>> list(String path) async {
    _segments(path, allowRoot: true);
    return (await _channel.invokeListMethod<dynamic>('list', {'path': path}) ?? [])
        .whereType<Map>()
        .map((e) => Map<String, dynamic>.from(e))
        .toList(growable: false);
  }

  Future<String> read(String path) async {
    _segments(path);
    return await _channel.invokeMethod<String>('read', {'path': path}) ?? '';
  }

  Future<Attachment> attachFile(
    String path, {
    required String expectedUri,
  }) async {
    _segments(path);
    if (_folder?['uri'] != expectedUri) {
      throw StateError('The selected project folder changed during this task.');
    }
    final exported = await _channel.invokeMapMethod<String, dynamic>(
      'export',
      {'path': path},
    );
    final sourcePath = exported?['path'] as String?;
    final name = exported?['name'] as String?;
    if (sourcePath == null || name == null || name.isEmpty) {
      throw StateError('The project file could not be exported.');
    }
    try {
      return await AttachmentStore.import(
        name: name,
        sourcePath: sourcePath,
        deferProcessing: true,
      );
    } finally {
      try {
        await File(sourcePath).delete();
      } catch (_) {}
    }
  }

  Future<void> write(String path, String content) async {
    _segments(path);
    await _channel.invokeMethod<bool>('write', {'path': path, 'content': content});
  }

  Future<void> mkdir(String path) async {
    _segments(path);
    await _channel.invokeMethod<bool>('mkdir', {'path': path});
  }

  Future<void> rename(String path, String name) async {
    _segments(path);
    _safeName(name);
    await _channel.invokeMethod<bool>('rename', {'path': path, 'name': name});
  }

  Future<void> move(String sourcePath, String destinationPath) async {
    _segments(sourcePath);
    _segments(destinationPath);
    await _channel.invokeMethod<bool>('move', {
      'sourcePath': sourcePath,
      'destinationPath': destinationPath,
    });
  }

  Future<void> delete(String path) async {
    _segments(path);
    await _channel.invokeMethod<bool>('delete', {'path': path});
  }

  List<ToolSpec> get specs => !isSelected ? const [] : const [
    ToolSpec(
      name: 'project_list_files',
      description: 'List files and folders ONLY inside the currently selected project folder. Use strict relative paths; use an empty path for the project root. Access outside this folder is blocked.',
      parameters: {'type': 'object', 'properties': {'path': {'type': 'string'}}, 'required': ['path']},
    ),
    ToolSpec(
      name: 'project_read_file',
      description: 'Read a UTF-8 text file ONLY inside the selected project folder. Absolute paths and parent traversal are rejected. Maximum 1 MB.',
      parameters: {'type': 'object', 'properties': {'path': {'type': 'string'}}, 'required': ['path']},
    ),
    ToolSpec(
      name: 'project_write_file',
      description: 'Create or overwrite a UTF-8 text file ONLY inside the selected project folder. Absolute paths and parent traversal are rejected. Parent folders are created inside the project only. Maximum 1 MB per file.',
      parameters: {'type': 'object', 'properties': {'path': {'type': 'string'}, 'content': {'type': 'string'}}, 'required': ['path', 'content']},
    ),
    ToolSpec(
      name: 'project_create_folder',
      description: 'Create a folder ONLY inside the selected project folder. Absolute paths and parent traversal are rejected.',
      parameters: {'type': 'object', 'properties': {'path': {'type': 'string'}}, 'required': ['path']},
    ),
    ToolSpec(
      name: 'project_rename',
      description: 'Rename a file or folder ONLY inside the selected project folder. Supply its strict relative path and a new basename. The project root cannot be renamed.',
      parameters: {'type': 'object', 'properties': {'path': {'type': 'string'}, 'name': {'type': 'string'}}, 'required': ['path', 'name']},
    ),
    ToolSpec(
      name: 'project_move',
      description: 'Move a file or folder ONLY within the selected project folder. The destination is a strict relative path including the new item name. Parent folders are created inside the project only. Do not move a folder into itself or a descendant. The destination must not already exist.',
      parameters: {'type': 'object', 'properties': {'source_path': {'type': 'string'}, 'destination_path': {'type': 'string'}}, 'required': ['source_path', 'destination_path']},
    ),
    ToolSpec(
      name: 'project_attach_file',
      description: 'Attach a file from the selected project folder to your reply as a downloadable chat attachment. Use only when the user explicitly asks you to provide or attach that file. The file is copied into app-private attachment storage; the project original is not changed. Maximum 64 MB.',
      parameters: {'type': 'object', 'properties': {'path': {'type': 'string'}}, 'required': ['path']},
    ),
    ToolSpec(
      name: 'project_delete',
      description: 'Permanently delete a file or folder and all its contents ONLY inside the selected project folder. Absolute paths and parent traversal are rejected. This is destructive and cannot be undone. Never use on the project root; inspect the target path first and delete only when the user explicitly asks or the task clearly requires removing that exact item.',
      parameters: {'type': 'object', 'properties': {'path': {'type': 'string'}}, 'required': ['path']},
    ),
  ];

  Future<ToolResult> call(ToolCall call, {required String expectedUri}) async {
    final watch = Stopwatch()..start();
    try {
      if (_folder?['uri'] != expectedUri) {
        throw StateError('The selected project folder changed during this task.');
      }
      final args = call.args;
      String argString(String key) {
        final value = args[key];
        if (value is! String || value.trim().isEmpty) throw FormatException('Missing $key.');
        return value;
      }
      // Not every tool uses `path`: move has source_path/destination_path.
      // Empty is valid only for listing the project root; native handlers
      // reject it for file operations and for project-root deletion.
      final pathValue = args['path'];
      var path = pathValue is String ? pathValue : '';
      // Small models sometimes call the selected folder root "project_root"
      // even though the schema explicitly documents an empty relative path.
      // Resolve that conventional root label without weakening path checks.
      if (call.name == 'project_list_files' &&
          const {'project_root', '.', '/'}.contains(path.trim())) {
        path = '';
      } else if (path.startsWith('project_root/')) {
        path = path.substring('project_root/'.length);
      }
      String output;
      switch (call.name) {
        case 'project_list_files':
          final entries = await list(path);
          output = const JsonEncoder.withIndent('  ').convert(entries);
          break;
        case 'project_read_file':
          output = await read(path);
          break;
        case 'project_write_file':
          final content = args['content'];
          if (content is! String) throw const FormatException('Missing content.');
          await write(path, content);
          output = 'Saved $path';
          break;
        case 'project_create_folder':
          await mkdir(path);
          output = 'Created folder $path';
          break;
        case 'project_rename':
          await rename(path, argString('name'));
          output = 'Renamed $path';
          break;
        case 'project_move':
          final source = argString('source_path');
          final destination = argString('destination_path');
          await move(source, destination);
          output = 'Moved $source to $destination';
          break;
        case 'project_attach_file':
          final attachment = await attachFile(path, expectedUri: expectedUri);
          return ToolResult(
            call: call,
            output: 'Attached ${attachment.name} (${attachment.sizeBytes} bytes) to the assistant reply.',
            ok: true,
            elapsedMs: watch.elapsedMilliseconds,
            attachments: [attachment],
          );
        case 'project_delete':
          await delete(path);
          output = 'Deleted $path';
          break;
        default:
          throw StateError('Unknown project tool ${call.name}.');
      }
      return ToolResult(call: call, output: output, ok: true, elapsedMs: watch.elapsedMilliseconds);
    } catch (e) {
      return ToolResult(call: call, output: 'Project folder error: $e', ok: false, elapsedMs: watch.elapsedMilliseconds);
    }
  }
}

final projectFolderProvider = ChangeNotifierProvider<ProjectFolderService>((ref) {
  final service = ProjectFolderService();
  service.load();
  return service;
});
