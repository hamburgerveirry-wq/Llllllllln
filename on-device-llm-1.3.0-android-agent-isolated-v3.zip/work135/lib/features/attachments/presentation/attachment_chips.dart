import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';

import 'package:flutter/material.dart';

import '../../../core/design/app_design.dart';
import '../../../core/design/app_sheet.dart';
import '../domain/attachment.dart';
import '../../../core/motion/motion.dart';
import '../../../core/l10n/l10n.dart';

/// Pending composer attachments are removable chips/thumbnails. Sent
/// attachments render as file cards with their type/size and save/share actions.
class AttachmentChips extends StatelessWidget {
  final List<Attachment> attachments;
  final ValueChanged<Attachment>? onRemove;
  const AttachmentChips({super.key, required this.attachments, this.onRemove});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Wrap(
      spacing: AppDesign.sm,
      runSpacing: AppDesign.sm,
      children: [
        for (final a in attachments)
          if (onRemove == null)
            _ReadOnlyAttachmentCard(attachment: a)
          else if (a.isImage)
            _Thumb(a, onRemove: onRemove)
          else
            InputChip(
              key: Key('attachment-${a.id}'),
              avatar: Icon(
                a.text == null
                    ? Icons.error_outline
                    : Icons.description_outlined,
                size: 16,
                color: a.text == null ? c.warning : c.textMuted,
              ),
              label: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 180),
                child: Text(
                  a.name,
                  overflow: TextOverflow.ellipsis,
                  style: context.text.mono.copyWith(color: c.text),
                ),
              ),
              onDeleted: () => onRemove!(a),
            ),
      ],
    );
  }

  static void _showText(
    BuildContext context,
    Attachment a,
  ) => showMorphSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (context) {
      final c = context.colors;
      return DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.6,
        maxChildSize: 0.95,
        builder: (context, scroll) => AppSheet(
          title: a.name,
          meta:
              '${a.mime} · ${(a.sizeBytes / 1024).toStringAsFixed(0)} KB'
              '${a.text != null ? ' · ${a.text!.length} characters given to the model' : ''}',
          scrollable: false,
          children: [
            ListView(
              controller: scroll,
              padding: EdgeInsets.zero,
              children: [
                if (a.isImage && a.text != null ||
                    a.text?.contains('(OCR;') == true) ...[
                  Text(
                    context.l10n.scanQualityHint,
                    style: context.text.bodyMuted,
                  ),
                  if (a.ocrConfidence != null)
                    Text(
                      '${context.l10n.scanConfidence} · ${(a.ocrConfidence! * 100).round()}%',
                      style: context.text.bodyMuted,
                    ),
                  const SizedBox(height: AppDesign.sm),
                ],
                SelectableText(
                  a.text ?? a.error ?? 'No text.',
                  style: a.text == null
                      ? context.text.bodyMuted.copyWith(color: c.warning)
                      : context.text.body,
                ),
              ],
            ),
          ],
        ),
      );
    },
  );
}

class _ReadOnlyAttachmentCard extends StatelessWidget {
  final Attachment attachment;
  const _ReadOnlyAttachmentCard({required this.attachment});

  Future<void> _save(BuildContext context) async {
    try {
      final bytes = await File(attachment.path).readAsBytes();
      await FilePicker.saveFile(
        dialogTitle: 'Save attachment',
        fileName: attachment.name,
        bytes: bytes,
        mimeType: attachment.mime,
      );
    } catch (error) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not save ${attachment.name}: $error')),
        );
      }
    }
  }

  Future<void> _share(BuildContext context) async {
    try {
      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(attachment.path, mimeType: attachment.mime)],
          subject: attachment.name,
        ),
      );
    } catch (error) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not share ${attachment.name}: $error')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final size = attachment.sizeBytes < 1024 * 1024
        ? '${(attachment.sizeBytes / 1024).toStringAsFixed(1)} KB'
        : '${(attachment.sizeBytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    return GestureDetector(
      onTap: attachment.text == null
          ? null
          : () => AttachmentChips._showText(context, attachment),
      child: Container(
        key: Key('attachment-card-${attachment.id}'),
        constraints: const BoxConstraints(maxWidth: 320),
        padding: const EdgeInsets.all(AppDesign.sm),
        decoration: BoxDecoration(
          color: c.surfaceRaised,
          border: Border.all(color: c.hairline),
          borderRadius: AppDesign.radius(AppDesign.rMd),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (attachment.isImage)
              ClipRRect(
                borderRadius: AppDesign.radius(AppDesign.rSm),
                child: Image.file(
                  File(attachment.path),
                  width: 48,
                  height: 48,
                  fit: BoxFit.cover,
                  errorBuilder: (_, _, _) => const SizedBox(
                    width: 48,
                    height: 48,
                    child: Icon(Icons.broken_image_outlined),
                  ),
                ),
              )
            else
              Icon(
                Icons.insert_drive_file_outlined,
                color: c.textMuted,
                size: 30,
              ),
            const SizedBox(width: AppDesign.sm),
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    attachment.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: context.text.mono.copyWith(color: c.text),
                  ),
                  Text(
                    '${attachment.mime} · $size',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: context.text.caption.copyWith(color: c.textMuted),
                  ),
                ],
              ),
            ),
            IconButton(
              tooltip: 'Save file',
              visualDensity: VisualDensity.compact,
              onPressed: () => _save(context),
              icon: const Icon(Icons.download_outlined, size: 20),
            ),
            IconButton(
              tooltip: 'Share file',
              visualDensity: VisualDensity.compact,
              onPressed: () => _share(context),
              icon: const Icon(Icons.share_outlined, size: 20),
            ),
          ],
        ),
      ),
    );
  }
}

class _Thumb extends StatelessWidget {
  final Attachment a;
  final ValueChanged<Attachment>? onRemove;
  const _Thumb(this.a, {this.onRemove});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    return Stack(
      clipBehavior: Clip.none,
      children: [
        GestureDetector(
          onTap: () => AttachmentChips._showText(context, a),
          child: ClipRRect(
            borderRadius: AppDesign.radius(AppDesign.rMd),
            child: Image.file(
              File(a.path),
              key: Key('attachment-${a.id}'),
              width: 72,
              height: 72,
              fit: BoxFit.cover,
              errorBuilder: (_, _, _) => Container(
                width: 72,
                height: 72,
                color: c.surfaceRaised,
                child: Icon(Icons.broken_image_outlined, color: c.textFaint),
              ),
            ),
          ),
        ),
        if (onRemove != null)
          Positioned(
            top: -6,
            right: -6,
            child: Material(
              color: c.surfaceOverlay,
              shape: const CircleBorder(),
              child: InkWell(
                customBorder: const CircleBorder(),
                onTap: () => onRemove!(a),
                child: const Padding(
                  padding: EdgeInsets.all(3),
                  child: Icon(Icons.close, size: 14),
                ),
              ),
            ),
          ),
      ],
    );
  }
}
