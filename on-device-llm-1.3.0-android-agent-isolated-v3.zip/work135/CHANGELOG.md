## 1.3.6 (2026-11-07)

### Procedural image output cap
- Enforce a strict 480p maximum for universal model-generated images: 854×480 landscape or 480×854 portrait.
- Default generation to 854×480; square images are limited to 480×480.
- Reject oversized dimensions before raster allocation/rendering, with regression tests for landscape and portrait overflow.

## 1.3.5 (2026-11-07)

### Universal procedural image generation
- Add a `generate_image` tool that can be called by any supported chat model when the user explicitly requests an image; ordinary questions do not offer or invoke it.
- Render model-authored, bounded scene instructions locally into PNG on a worker isolate; no diffusion weights, external image API, or executable model-generated code are required.
- Attach generated PNGs to the assistant message so the existing image preview and Save/Download controls work.
- Bound output to 2048×2048 pixels and 160 drawing elements, validate colors and dimensions, and store output in the app's attachment directory.
- Support gradients, rectangles, circles, ellipses, lines, and filled/outlined polygons. This is procedural illustration, not photorealistic diffusion generation.
- Add image-intent regression tests.

## 1.3.4

- Android GPU loading now retries progressively smaller GPU layer counts before falling back to CPU-only, preserving hybrid CPU/GPU inference when full offload does not fit.
- Added a separate Android Vulkan native variant for Mali/Immortalis-class GPUs, while retaining the OpenCL path for compatible Adreno devices and a CPU-safe fallback library.
- Android hardware settings expose Vulkan as a selectable backend; automatic selection can use either OpenCL or Vulkan.
- GPU library probing skips variants that load but enumerate no compute GPU, and prefers Vulkan for detected Mali/Immortalis GPUs while retaining OpenCL for Adreno.
- Kept the OpenCL kernel cache path configurable even when the lightweight GPU probe initializes the backend first.

# Changelog

## 1.3.3 (2026-11-07)

### Tool execution and mobile integrations
- Recover valid calls to tools offered in the current turn when a model wraps
  the JSON call in ordinary prose, not only when it uses a recognizable
  tutorial phrase. Recovery is limited to explicit operation requests or a
  response already classified as a tool tutorial, and only uses tools offered
  for the current turn.
- Hide offered tool-call JSON while it streams so raw function arguments do
  not flash in the chat.
- Reject obvious placeholder arguments in the normal text-tool parser as
  well as in recovery paths; retry the model for grounded arguments instead
  of executing sample paths or sample file contents.
- Keep Android MCP setup focused on the guided endpoint + optional bearer-key
  flow; the raw JSON editor remains available on desktop for stdio and
  advanced configurations.
- Let explicit GPU backend selection accept accelerator-class devices as well
  as GPU/IGPU-class devices, while still excluding CPU-only devices.

### Verification notes
- Added regression tests for JSON tool calls embedded in prose, streamed-call
  hiding, placeholder rejection, and preservation of ordinary JSON answers.
- Flutter/Dart and Android SDK/NDK toolchains are not present in this build
  environment, so Flutter tests, analyzer, APK compilation, and device
  benchmarks must be run on a configured development machine.

## 1.3.2 (2026-11-07)

### Local inference and agent reliability
- Keep the Android Automatic backend policy intact through model loading; the
  native runtime can now actually attempt GPU selection instead of being
  pre-emptively forced to CPU by the model manager.
- Android Auto now considers every compatible OpenCL GPU, including Adreno
  and Mali devices. If GPU initialization or model loading fails, the native
  runtime retries on CPU and reports the real fallback reason.
- Explicit OpenCL selection remains a manual GPU attempt; it is not rejected
  merely because Auto did not select the device. A missing driver/backend is
  reported honestly instead of being presented as GPU acceleration.
- Require an actual project tool call for clear project-file actions and
  explicit tool-check requests when project tools are connected. How-to
  questions remain explanatory and do not trigger filesystem actions.
- Remove project-file JSON examples from the plain-text tool instructions to
  reduce small models copying illustrative paths and file contents.
- Tune Android Auto GPU decode threads to the measured 4-thread feeder default while preserving the CPU fallback thread count and any explicit user override.
- Update hardware guidance and regression tests for GPU-first Auto behavior.

## 1.3.1 (2026-11-07)

### Agent tools and integrations
- Recover offered tool calls when a local model wraps a real JSON call in a
  tutorial-style explanation; only tools available in the current turn are
  eligible, and obvious placeholder arguments are rejected. The chat hides
  the instructional JSON while the host processes the call.
- Resolve the common `project_root` label to the selected project folder root
  for file listings, while retaining the Android Storage Access Framework
  path restrictions.
- Move MCP server and project-folder management out of the chat composer sheet
  and keep both entry points in Settings > Tools.
- Add optional bearer API-key authentication for HTTP MCP endpoints. Tokens
  are stored with secure storage and sent as Authorization headers, never
  written to the MCP JSON configuration or chat logs.
- Make Android's explicit OpenCL backend choice visibly distinguishable from
  Automatic: it attempts OpenCL even for devices Auto does not select. Auto
  continues to fall back to CPU when no supported GPU is usable.

## 1.3.0 (2026-11-03)

### Remote server workspace (Android and Windows)

- Connecting to an updated OnDevice LLM server moves chat model rounds,
  agents, web searches, server tools, calculator and attachment processing
  to the host. The phone can use this mode without a local model installed.
- Live server activity, agent replies, timings, sources and tool approvals
  appear on the phone. The answer retains the server tool trace.
- Phone actions are prepared on the server and remain cards you confirm
  on the phone; nothing is launched or scheduled without your tap.
- Selected files upload as raw bytes for host-side document extraction,
  OCR, passage selection and photo analysis, respecting the connection's
  document and vision sharing controls.
- Server jobs keep working across connection loss. Rejoining replays ordered
  events without repeating the work; Stop explicitly cancels the server job.
  Jobs remain available while hosting stays running; restarting the server
  ends them. Uploads and event retention have explicit resource limits.
- Vision remains lazy: text-only loads do not load the projector. The first
  photo prepares it, and later photo requests reuse the loaded projector.
- Existing OpenAI-compatible and hosted providers retain their inference API
  behavior; full remote execution requires an updated OnDevice LLM host.

### Fixes

- Generate the Windows engine manifest in minimal PowerShell environments
  using .NET SHA-256 without requiring the Get-FileHash module.
- Fix remote helper-agent turns failing with `Tool messages require tool_call_id`
  when a model emits a tool call without an ID. Missing IDs are assigned before
  calls are sent to clients or executed; existing IDs are preserved.

## 1.2.0 (2026-11-02)

Adds local agents: the chat model can work as a team.

### Local agents (new, Android and Windows)
- The chat model can split a task and hand parts of it to up to 4 agents
  that run side by side, then write one answer from all of their replies.
  The answer records how many times it asked the agents.
- Agents share one copy of the agent model; on Windows their jobs are
  batched together on the GPU.
- Pick the agent model ("Same as chat model" or a second model), how many
  run at once, thinking, tool rounds, instructions, input budget, context
  size and sampling in Settings > Tools > Agents.
- Agents can use the chat tools, including web search. Web access is asked
  once per chat, always allowed, or never allowed.
- Live agent cards on Windows and a small agent strip above the composer on
  the phone, with each task, its streamed reply, tokens/s and timings.
- The chosen agent model is always the one that runs.

### Engine
- Models and agents fill the GPU's VRAM first and only then spill into
  system RAM, on any GPU.
- The Logs page shows every model load (with the real GPU layer count),
  agent job, tool call, search and download.

### Chat and voice
- `/` command palette; `/compact` summarises older turns after you approve
  the summary.
- Model pages with the Hugging Face card, GGUF capabilities, files, load
  settings and the model's own sampling settings; a downloads center with
  history.
- Vision is a per-model switch, loaded with the first photo.
- Optional Supertonic 2 reading voice (English, French and Spanish).
- Dictation keeps listening across short pauses.
- Warm-grey light theme and redesigned desktop settings.
- Fixes for read-aloud on Windows, tool-call parsing for Qwen models and
  many smaller issues found in a full audit.

## 1.1.0 (2026-10-29)

Adds the Windows desktop app.

### Windows desktop (new)
- The same app on Windows 10 and 11 (64-bit), with a desktop layout,
  keyboard shortcuts, a tray icon and live logs. Installer and ZIP, no
  administrator rights needed.
- Engines for NVIDIA CUDA 13 and CUDA 12, Vulkan, AVX-512, AVX2 and older
  CPUs; the app picks the best one that works on your PC.
- Optimize for this PC: tries several setups and keeps the fastest one that
  gives the same answers. A memory estimate before loading shows what fits
  in VRAM and RAM.
- Large mixture-of-experts models (for example Qwen3.6 35B A3B) with experts
  in system RAM, multi-token prediction (MTP) and draft models.
- Hugging Face Discover, model Compare, and Create for images, short video
  and upscaling.
- Local server with OpenAI- and Anthropic-compatible endpoints, token
  protected, and phone pairing over your network.

### Engine
- llama.cpp updated to b11972.
- The whole model, output layer included, now fits on the GPU when it can,
  and sampling runs on the GPU, also with MTP.
- Faster first token on the desktop.

### Android
- Picking a remote connection turns Remote on with it.
- Many fixes from the desktop work that also apply to the phone (prompt
  reuse, tool progress, document fitting).

## 1.0.0 (2026-10-21)

First public release. Android only.

### Chat
- Local GGUF inference on a pinned llama.cpp through a small versioned C
  bridge, on the CPU with optional OpenCL. Answers stream with stop,
  continue, regenerate, edit and answer versions.
- Gemma 4 and Qwen models in a catalog pinned by revision and SHA-256, plus
  GGUF import and Hugging Face browsing.
- Each model's recommended sampling (model card, Hugging Face or GGUF
  metadata) is used by default. Settings layer from phone to model, preset,
  project, chat and turn, with an Effective settings page.
- Chats in SQLite with search, projects, archive and trash, Markdown/JSON
  export and temporary chats.
- Optional memory of facts you state, which you can edit and delete.

### Photos and documents
- Photo questions through Gemma 4 or a Qwen3.5 vision projector; photo turns
  stay in the prompt cache, so follow-up questions do not re-encode the image.
- On-device text recognition (OCR) for photos.
- Text from PDF, Word, Excel, PowerPoint, OpenDocument, EPUB, RTF, HTML,
  CSV and plain text; long files are cut to the passages matching the
  question.
- Knowledge collections searched by keyword and meaning (EmbeddingGemma 2),
  with cited passages.

### Web research
- DuckDuckGo search with page reading, Wikipedia for stable facts, a news
  desk from public RSS feeds and an optional offline Wikipedia (ZIM).
- Cited answers: each source opens to the exact passage. Every sentence is
  checked against the pages and unsupported statements are flagged. Dates
  are checked, and a follow-up re-reads earlier pages or searches again.
- Off by default.

### Voice
- Dictation and read-aloud.
- Conversation screen: Whisper or Parakeet speech recognition, a local or
  remote model and Kokoro speech, hands-free.

### Goals and actions
- Goals: clarifying questions, a step plan, research with sources and a
  report.
- Phone actions (timers, alarms, reminders, calendar events, message drafts,
  saved files) prepared as cards that need a tap.

### Connections
- Remote connections to your own server (LM Studio, Ollama, llama-server…)
  or hosted APIs (OpenAI-compatible, Anthropic, Gemini). The remote model
  decides when to search and keeps its server's own settings. Keys are kept
  in the Android keystore, and you can set per-model request limits.
- Device server: the phone serves its model to your network through an
  OpenAI-compatible endpoint.

### Interface
- English, French and Spanish.
- One motion system with spring animations, a status island with Undo
  toasts, haptics, dark and light themes and a Full/Subtle/Off motion
  setting.

### Known limits
See [Known limits](README.md#known-limits) in the README: no iOS release,
no background downloads, no encrypted backup, LoRA untested on hardware and
Gemini untested live.

## 0.1.1 (2026-10-11)

Internal test build installed on the development phone (release 8).

## 0.1.0 (2026-09-14)

Start of the project: pinned llama.cpp, Jinja chat templates and the
Android build.
