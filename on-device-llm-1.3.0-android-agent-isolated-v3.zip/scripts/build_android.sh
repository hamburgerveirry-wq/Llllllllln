#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bash scripts/bootstrap.sh
# The Linux build keeps the generic bridge CPU-safe; use the Windows Android
# build script for the separately packaged Vulkan variant and pinned shader toolchain.
export ORG_GRADLE_PROJECT_odllmVulkan=OFF # keep the generic bridge as a CPU-safe fallback
# Build the OpenCL bridge separately; keep Gradle compatibility bridge CPU-only.
export ORG_GRADLE_PROJECT_odllmOpenCL=OFF
# Keep optimized CPU kernels in Linux/CI releases as well as Windows builds.
sdk_root="${ANDROID_HOME:-${ANDROID_SDK_ROOT:?Set ANDROID_HOME or ANDROID_SDK_ROOT}}"
ndk="$sdk_root/ndk/28.2.13676358"
cmake_bin="$sdk_root/cmake/3.22.1/bin/cmake"
ninja_bin="$sdk_root/cmake/3.22.1/bin/ninja"
if [[ ! -x "$cmake_bin" || ! -d "$ndk" ]]; then
  # sdkmanager is not on PATH on the GitHub runners.
  sdkmanager_bin="$sdk_root/cmdline-tools/latest/bin/sdkmanager"
  [[ -x "$sdkmanager_bin" ]] || sdkmanager_bin=sdkmanager
  "$sdkmanager_bin" "cmake;3.22.1" "ndk;28.2.13676358"
fi
"$cmake_bin" -S native -B build/native-cpu-i8mm/arm64-v8a -G Ninja \
  "-DCMAKE_MAKE_PROGRAM=$ninja_bin" -DCMAKE_BUILD_TYPE=Release \
  "-DCMAKE_TOOLCHAIN_FILE=$ndk/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-28 -DANDROID_STL=c++_static \
  -DODLLM_OPENCL=OFF -DODLLM_VULKAN=OFF -DODLLM_KLEIDIAI=OFF \
  -DODLLM_LIBRARY_NAME=ondevice_llm_cpu_i8mm \
  -DODLLM_ARM_ARCH=armv8.6-a+dotprod+i8mm+fp16
"$cmake_bin" --build build/native-cpu-i8mm/arm64-v8a --target ondevice_llm_cpu_i8mm
mkdir -p android/app/src/main/jniLibs/arm64-v8a
cp build/native-cpu-i8mm/arm64-v8a/libondevice_llm_cpu_i8mm.so android/app/src/main/jniLibs/arm64-v8a/

# Ship a portable ARMv8-A OpenCL bridge beside the fast CPU variant. The GPU
# library must not require i8mm: many Mali/Adreno phones have OpenCL but lack
# that CPU extension. The loader tries OpenCL first, then the i8mm CPU build
# when supported, then the portable Gradle bridge.
opencl_mode="${ODLLM_OPENCL:-ON}"
if [[ "$opencl_mode" == "ON" ]]; then
  mkdir -p .tools
  if [[ ! -f .tools/OpenCL-Headers/CL/cl.h ]]; then
    rm -rf .tools/OpenCL-Headers
    git clone --depth 1 --branch v2024.10.24 https://github.com/KhronosGroup/OpenCL-Headers.git .tools/OpenCL-Headers
  fi
  test "$(git -C .tools/OpenCL-Headers rev-parse HEAD)" = "4ea6df132107e3b4b9407f903204b5522fdffcd6"
  if [[ ! -f .tools/OpenCL-ICD-Loader/CMakeLists.txt ]]; then
    rm -rf .tools/OpenCL-ICD-Loader
    git clone --depth 1 --branch v2024.10.24 https://github.com/KhronosGroup/OpenCL-ICD-Loader.git .tools/OpenCL-ICD-Loader
  fi
  test "$(git -C .tools/OpenCL-ICD-Loader rev-parse HEAD)" = "5907ac1114079de4383cecddf1c8640e3f52f92b"
  if [[ ! -f .tools/OpenCL-ICD-Loader/build-android/libOpenCL.so ]]; then
    "$cmake_bin" -S .tools/OpenCL-ICD-Loader -B .tools/OpenCL-ICD-Loader/build-android -G Ninja \
      "-DCMAKE_MAKE_PROGRAM=$ninja_bin" -DCMAKE_BUILD_TYPE=Release \
      "-DCMAKE_TOOLCHAIN_FILE=$ndk/build/cmake/android.toolchain.cmake" \
      -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=28 \
      "-DOPENCL_ICD_LOADER_HEADERS_DIR=$PWD/.tools/OpenCL-Headers" \
      -DOPENCL_ICD_LOADER_BUILD_TESTING=OFF -DBUILD_TESTING=OFF
    "$cmake_bin" --build .tools/OpenCL-ICD-Loader/build-android --target OpenCL
  fi
  "$cmake_bin" -S native -B build/native-opencl/arm64-v8a -G Ninja \
    "-DCMAKE_MAKE_PROGRAM=$ninja_bin" -DCMAKE_BUILD_TYPE=Release \
    "-DCMAKE_TOOLCHAIN_FILE=$ndk/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-28 -DANDROID_STL=c++_static \
    -DODLLM_OPENCL=ON -DODLLM_VULKAN=OFF -DODLLM_KLEIDIAI=OFF \
    -DODLLM_LIBRARY_NAME=ondevice_llm_opencl -DODLLM_ARM_ARCH=armv8-a
  "$cmake_bin" --build build/native-opencl/arm64-v8a --target ondevice_llm_opencl
  cp build/native-opencl/arm64-v8a/libondevice_llm_opencl.so android/app/src/main/jniLibs/arm64-v8a/
else
  rm -f android/app/src/main/jniLibs/arm64-v8a/libondevice_llm_opencl.so
fi

dart scripts/prepare_release_registrant.dart
flutter build apk --release --target-platform android-arm64 --no-pub
unzip -Z1 build/app/outputs/flutter-apk/app-release.apk | grep -Fx 'lib/arm64-v8a/libondevice_llm_cpu_i8mm.so'
if [[ "$opencl_mode" == "ON" ]]; then
  unzip -Z1 build/app/outputs/flutter-apk/app-release.apk | grep -Fx 'lib/arm64-v8a/libondevice_llm_opencl.so'
fi
