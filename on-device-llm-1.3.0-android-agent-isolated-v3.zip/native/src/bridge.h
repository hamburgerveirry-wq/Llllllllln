#pragma once
#include <stdint.h>
#if defined(_WIN32)
#define OD_API __declspec(dllexport)
#else
#define OD_API __attribute__((visibility("default"))) __attribute__((used))
#endif
#ifdef __cplusplus
extern "C" {
#endif
OD_API int32_t od_version(void);
// Additive optional query: hardware GPUs (discrete or integrated), zero on failure.
OD_API int32_t od_gpu_device_count(void);
// Additive optional query: the CPU cores llama.cpp uses by default
// (physical cores), at least 1. Load settings with effectiveThreads or
// effectiveBatchThreads <= 0 use this count.
OD_API int32_t od_cpu_cores(void);
// options: JSON, e.g. {"cacheDir": "/data/user/0/<pkg>/cache", "owner": 3}.
// Backends that compile kernels (OpenCL) persist them under cacheDir; empty
// disables the cache. owner tags the runtime with the window that made it.
OD_API void * od_create(const char * options);
OD_API void od_destroy(void * handle);
// Frees the models of every runtime created with that owner and refuses
// further work on them: an Android window closed while the process lives
// on. Callable from any thread; returns how many models were freed.
OD_API int32_t od_release_owner(int64_t owner);
// Thread-safe cancellation by stable session id; stale ids are harmless.
// These additive ABI 6 exports never access a runtime from the calling thread.
OD_API int64_t od_session_id(void * handle);
OD_API void od_cancel_session(int64_t session);
OD_API void od_reset_cancel(void * handle);
OD_API int32_t od_cancelled(void * handle);
OD_API const char * od_error(void * handle);
// Includes embeddedChatTemplate from the GGUF, even when a load override is active.
OD_API const char * od_info(void * handle);
// JSON prompt budget and formattedPrompt without trimming history or changing generation state.
OD_API const char * od_preview(void * handle, const char * request);
// settings (JSON): context/threads/backend as before, plus (ABI 6)
//   kvCacheType / vCacheType, ropeScaling + rope/yarn numbers,
//   chatTemplate: non-empty Jinja override (parse errors fail the load),
//   loraAdapters: [{path, scale}], draftModel + draftMaxTokens (speculative).
//   mtp: use the model's own NextN heads (default false; ignored without heads
//   or with draftModel). od_info reports mtp and mtpAcceptRate; ABI stays 7.
// The context is capped to the model's trained length and to free memory
// (memoryGuard: false turns that off); od_info's effectiveSettings reports
// contextRequested and contextCap ("", "train" or "memory").
OD_API int32_t od_load(void * handle, const char * path, const char * settings);
// Additive (optional lookup), safe from another thread: 0..1 during od_load,
// -1 for an unknown session or when idle. Completion is 1 before returning.
OD_API float od_load_progress(int64_t session);
// request (JSON): messages (role/content, optional images, tool_calls,
// tool_call_id), settings (sampling, stop sequences, seed, response format),
// tools: [{name, description, parameters}] for native tool calling.
OD_API int32_t od_begin(void * handle, const char * request);
// 0 = prefill progress, 1 = token bytes, 2 = end, -1 = error. A step may
// emit several tokens at once (speculative decoding) or none (a stop
// sequence prefix is being held back).
OD_API int32_t od_step(void * handle, uint8_t * output, int32_t capacity, int32_t * length);
// Independent batched helper context sharing the runtime's immutable weights.
// All side calls run on one worker. Runtime unload invalidates it before freeing weights.
OD_API void * od_side_open(void * handle, const char * options);
// 0 admitted, 1 retry after live work drains, -1 invalid request (owner, 2026-11-02).
OD_API int32_t od_side_submit(void * side, int32_t seq, const char * request);
// JSON events with token bytes, done and per-sequence metrics; valid until the next side call.
OD_API const char * od_side_step(void * side);
OD_API void od_side_cancel(void * side, int32_t seq);
OD_API void od_side_close(void * side);
// Embedding models (loaded with settings {"embedding": true}): request
// {"texts": [...]} -> {"dim": n, "vectors": [[...], ...]}, L2-normalised.
OD_API const char * od_embed(void * handle, const char * request);
// Reads GGUF metadata of a LoRA adapter without loading a model:
// {"architecture", "type", "name", "keys": {...}} or null (see od_error).
OD_API const char * od_adapter_info(void * handle, const char * path);
// Additive (optional lookup): what loading [path] with [settings] (the od_load JSON) would use,
// without loading it: {"contextSize", "layers", "gpuLayers", "ramNeedMb",
// "vramNeedMb", "gpuFit", "backend", "devices": [...], "ramAvailableMb",
// "ramTotalMb"}, or null (see od_error). An empty path lists the devices.
OD_API const char * od_estimate(void * handle, const char * path, const char * settings);
#ifdef __cplusplus
}
#endif
