import 'package:flutter_test/flutter_test.dart';
import 'package:ondevice_llm/features/tools/procedural_image_tool.dart';

void main() {
  group('procedural image tool intent', () {
    test('offers image generation for explicit creation requests', () {
      expect(ProceduralImageTool.wanted('Generate an image of a tiny dragon'), isTrue);
      expect(ProceduralImageTool.wanted('Draw me a cyberpunk wallpaper'), isTrue);
      expect(ProceduralImageTool.wanted('Create a logo for my game'), isTrue);
      expect(ProceduralImageTool.wanted('Make a picture of a mountain at sunset'), isTrue);
      expect(ProceduralImageTool.wanted('I want an image of a red fox'), isTrue);
      expect(ProceduralImageTool.wanted('Draw a little dragon'), isTrue);
    });

    test('does not offer image generation for ordinary questions', () {
      expect(ProceduralImageTool.wanted('How does image generation work?'), isFalse);
      expect(ProceduralImageTool.wanted('How do I create an image?'), isFalse);
      expect(ProceduralImageTool.wanted('What is a PNG image?'), isFalse);
      expect(ProceduralImageTool.wanted('Tell me about cyberpunk artwork'), isFalse);
      expect(ProceduralImageTool.wanted('Hello there'), isFalse);
    });
  });

  group('480p output limit', () {
    test('tool schema advertises 480p defaults and limits', () {
      final properties = ProceduralImageTool.spec.parameters['properties'] as Map;
      expect(properties['width']['description'], contains('854'));
      expect(properties['height']['description'], contains('480'));
    });

    test('rejects landscape output above 480p before rendering', () async {
      await expectLater(
        ProceduralImageTool.generate({
          'width': 854,
          'height': 481,
          'elements': [{'shape': 'rect', 'color': '#FFFFFF'}],
        }),
        throwsA(isA<FormatException>().having(
          (e) => e.message, 'message', contains('480p'),
        )),
      );
    });

    test('rejects portrait output above 480p before rendering', () async {
      await expectLater(
        ProceduralImageTool.generate({
          'width': 481,
          'height': 854,
          'elements': [{'shape': 'rect', 'color': '#FFFFFF'}],
        }),
        throwsA(isA<FormatException>().having(
          (e) => e.message, 'message', contains('480p'),
        )),
      );
    });
  });

}
