import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ondevice_llm/features/tools/project_folder.dart';
import 'package:ondevice_llm/features/tools/domain/tool_spec.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const channel = MethodChannel('ondevice_llm/project_folder');
  final calls = <MethodCall>[];
  var selected = false;

  setUp(() {
    calls.clear();
    selected = false;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (call) async {
          calls.add(call);
          switch (call.method) {
            case 'currentFolder':
              return selected ? {'uri': 'content://tree/test', 'name': 'test'} : null;
            case 'pickFolder':
              selected = true;
              return {'uri': 'content://tree/test', 'name': 'test'};
            case 'list':
              return [
                {'name': 'lib', 'directory': true, 'size': 0, 'path': 'lib'},
              ];
            case 'read':
              return 'void main() {}';
            case 'write':
            case 'mkdir':
            case 'rename':
            case 'move':
            case 'delete':
            case 'clearFolder':
              return true;
            default:
              throw MissingPluginException();
          }
        });
  });

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, null);
  });

  test('project tools stay unavailable until a folder is selected', () async {
    final service = ProjectFolderService();
    await service.load();
    expect(service.isSelected, isFalse);
    expect(service.specs, isEmpty);
    service.dispose();
  });

  test('selected folder exposes bounded relative-path agent tools', () async {
    final service = ProjectFolderService();
    await service.selectFolder();
    expect(service.folder?['name'], 'test');
    expect(service.specs.map((e) => e.name), containsAll([
      'project_read_file', 'project_move', 'project_delete',
    ]));
    final result = await service.call(const ToolCall(
      id: '1', name: 'project_read_file', arguments: '{"path":"lib/main.dart"}',
    ), expectedUri: 'content://tree/test');
    expect(result.ok, isTrue);
    expect(result.output, 'void main() {}');
    expect(calls.map((e) => e.method), contains('read'));
    final moved = await service.call(const ToolCall(
      id: '2', name: 'project_move',
      arguments: '{"source_path":"src/old.dart","destination_path":"lib/old.dart"}',
    ), expectedUri: 'content://tree/test');
    expect(moved.ok, isTrue);
    final deleted = await service.call(const ToolCall(
      id: '3', name: 'project_delete', arguments: '{"path":"build/cache"}',
    ), expectedUri: 'content://tree/test');
    expect(deleted.ok, isTrue);
    expect(calls.map((e) => e.method), containsAll(['move', 'delete']));
    service.dispose();
  });
  test('project service rejects paths that could escape the selected tree', () async {
    final service = ProjectFolderService();
    await service.selectFolder();
    final before = calls.length;
    expect(() => service.read('../outside.txt'), throwsFormatException);
    expect(() => service.read('/storage/emulated/0/private.txt'), throwsFormatException);
    expect(() => service.move('src/a', r'..\outside\a'), throwsFormatException);
    expect(() => service.delete(''), throwsFormatException);
    expect(calls.length, before, reason: 'Invalid paths must be rejected before reaching Android.');
    service.dispose();
  });

}
