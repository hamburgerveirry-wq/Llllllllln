# Faster local replies

The **Faster** preset in Settings Search is a latency/length trade-off:

- Disables model reasoning for ordinary replies and agent replies.
- Caps ordinary replies at 512 generated tokens and agent replies at 384.
- Does not change the context window, loaded model, GPU backend, or CPU thread settings.

This makes answers finish sooner when the model would otherwise spend time reasoning or generate long responses. It does **not** claim to increase the model's raw tokens-per-second rate. Raw throughput depends on the selected backend, the device's driver, model quantization and memory bandwidth. On Mali, a Vulkan backend must first compile and be confirmed working on that exact device before it can be counted as a speed improvement. A smaller quantization such as Q4 can also improve throughput on memory-bandwidth-limited phones, with a quality trade-off.
