# Local OpenAI-compatible API

1. Load a local chat model in the app.
2. Open **Local API** and tap **Start server**.
3. Copy the Base URL, API key and Model ID shown on screen. If port `8787` is already occupied, the app automatically selects an available port and displays the actual URL.
4. In an OpenAI-compatible client, set:

```dotenv
OPENAI_BASE_URL=http://PHONE-LAN-IP:PORT/v1/
OPENAI_API_KEY=the-generated-key
OPENAI_MODEL=the-model-id-shown-in-the-app
```

The server implements `GET /v1/models` and `POST /v1/chat/completions`, including Server-Sent Events streaming. Authenticate with `Authorization: Bearer <API key>`. The base URL already includes `/v1/`; clients append `chat/completions` themselves.

Example using the OpenAI Python SDK:

```python
from openai import OpenAI
import os

client = OpenAI(
    base_url=os.environ["OPENAI_BASE_URL"],
    api_key=os.environ["OPENAI_API_KEY"],
)

response = client.chat.completions.create(
    model=os.environ["OPENAI_MODEL"],
    messages=[{"role": "user", "content": "Say hello."}],
    stream=True,
)
for chunk in response:
    if chunk.choices and chunk.choices[0].delta.content:
        print(chunk.choices[0].delta.content, end="", flush=True)
```

The API key is generated with a cryptographically secure random source and stored in Android secure storage so it remains the same across server restarts. The listener is intended for the local network; it rejects requests from public source addresses. Do not share the key or expose the phone through router port forwarding.
