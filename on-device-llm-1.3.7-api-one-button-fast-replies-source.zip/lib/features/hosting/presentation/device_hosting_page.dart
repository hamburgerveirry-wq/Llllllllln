import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/design/app_design.dart';
import '../../../core/island/status_island.dart';
import '../../../core/l10n/l10n.dart';
import '../../models/presentation/providers/model_manager_provider.dart';
import 'device_hosting_provider.dart';

/// Minimal local OpenAI-compatible API host: one Start/Stop control, with the
/// exact base URL, key and model needed by a client once the server is live.
class DeviceHostingPage extends ConsumerStatefulWidget {
  const DeviceHostingPage({super.key});

  @override
  ConsumerState<DeviceHostingPage> createState() => _DeviceHostingPageState();
}

class _DeviceHostingPageState extends ConsumerState<DeviceHostingPage> {
  static const _defaultPort = 8787;
  bool _showToken = false;

  Future<void> _copy(String label, String value) async {
    if (value.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: value));
    if (!mounted) return;
    showIslandToast(
      context,
      context.l10n.hostCopied(label),
      tone: IslandTone.done,
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(deviceHostingProvider);
    final model = ref.watch(modelManagerProvider).loadedModel;
    final controller = ref.read(deviceHostingProvider.notifier);
    final colors = context.colors;
    final token = state.token ?? '';
    final endpoint = state.endpoint ?? '';
    final modelId = state.modelId ?? model?.id ?? '';
    final setup =
        'OPENAI_BASE_URL=$endpoint\nOPENAI_API_KEY=$token\nOPENAI_MODEL=$modelId';

    return Scaffold(
      appBar: AppBar(title: Text(context.l10n.hostTitle)),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppDesign.lg,
            AppDesign.md,
            AppDesign.lg,
            AppDesign.xxl,
          ),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(AppDesign.lg),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          state.running
                              ? Icons.cloud_done_outlined
                              : Icons.cloud_outlined,
                          color: state.running
                              ? colors.success
                              : colors.textMuted,
                          size: 28,
                        ),
                        const SizedBox(width: AppDesign.md),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                state.running
                                    ? 'API server running'
                                    : 'Local API server',
                                style: context.text.title,
                              ),
                              Text(
                                state.running
                                    ? (state.modelId ?? '')
                                    : (model?.displayName ??
                                          context.l10n.hostLoadFirst),
                                style: context.text.bodyMuted,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    if (state.error != null) ...[
                      const SizedBox(height: AppDesign.md),
                      Text(
                        state.error!,
                        style: context.text.body.copyWith(color: colors.danger),
                      ),
                    ],
                    if (state.stoppedReason != null && !state.running) ...[
                      const SizedBox(height: AppDesign.md),
                      Text(
                        state.stoppedReason!,
                        style: context.text.body.copyWith(color: colors.warning),
                      ),
                    ],
                    const SizedBox(height: AppDesign.lg),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        key: const Key('host-start-stop'),
                        onPressed: state.starting
                            ? null
                            : state.running
                                ? () => controller.stop()
                                : model == null
                                    ? null
                                    : () =>
                                          controller.start(port: _defaultPort),
                        icon: state.starting
                            ? const SizedBox.square(
                                dimension: 18,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : Icon(state.running ? Icons.stop : Icons.play_arrow),
                        label: Text(
                          state.starting
                              ? context.l10n.hostStarting
                              : state.running
                                  ? 'Stop server'
                                  : 'Start server',
                        ),
                      ),
                    ),
                    const SizedBox(height: AppDesign.sm),
                    Text(
                      'Uses the currently loaded model. The server is limited to your local network; it is not exposed as a public internet API.',
                      style: context.text.bodyMuted,
                    ),
                  ],
                ),
              ),
            ),
            if (state.running) ...[
              const SizedBox(height: AppDesign.lg),
              _ConnectionValue(
                title: 'Base URL',
                value: endpoint,
                onCopy: () => _copy('Base URL', endpoint),
              ),
              const SizedBox(height: AppDesign.md),
              _ConnectionValue(
                title: 'Model ID',
                value: modelId,
                onCopy: () => _copy('Model ID', modelId),
              ),
              const SizedBox(height: AppDesign.md),
              _ConnectionValue(
                title: 'API key',
                value: _showToken
                    ? token
                    : '•••••••• ${token.length > 4 ? token.substring(token.length - 4) : ''}',
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      tooltip: _showToken ? 'Hide API key' : 'Show API key',
                      onPressed: () => setState(() => _showToken = !_showToken),
                      icon: Icon(
                        _showToken
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                      ),
                    ),
                    IconButton(
                      tooltip: 'Copy API key',
                      onPressed: () => _copy('API key', token),
                      icon: const Icon(Icons.copy),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppDesign.md),
              OutlinedButton.icon(
                key: const Key('copy-api-setup'),
                onPressed: () => _copy('API setup', setup),
                icon: const Icon(Icons.copy_all_outlined),
                label: const Text('Copy API setup'),
              ),
              const SizedBox(height: AppDesign.sm),
              Text(
                'Paste the copied values into a client that accepts OpenAI environment variables. The API supports /v1/models and /v1/chat/completions, including streamed replies.',
                style: context.text.bodyMuted,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _ConnectionValue extends StatelessWidget {
  const _ConnectionValue({
    required this.title,
    required this.value,
    required this.onCopy,
    this.trailing,
  });

  final String title;
  final String value;
  final VoidCallback onCopy;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.fromLTRB(
        AppDesign.md,
        AppDesign.sm,
        AppDesign.sm,
        AppDesign.sm,
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: context.text.label),
                const SizedBox(height: 4),
                SelectableText(value, style: context.text.mono),
              ],
            ),
          ),
          trailing ??
              IconButton(
                tooltip: 'Copy $title',
                onPressed: onCopy,
                icon: const Icon(Icons.copy),
              ),
        ],
      ),
    ),
  );
}
