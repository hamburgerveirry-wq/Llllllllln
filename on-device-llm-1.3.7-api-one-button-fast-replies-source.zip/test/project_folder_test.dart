import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ondevice_llm/features/tools/project_folder.dart';
import 'package:ondevice_llm/features/tools/domain/tool_spec.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const channel = MethodChannel('ondevice_llm/project_folder');
  final calls = <MethodCall>[];
  final storedFiles = <String, String>{};
  var selected = false;

  setUp(() {
    calls.clear();
    storedFiles.clear();
    selected = false;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (call) async {
          calls.add(call);
          switch (call.method) {
            case 'currentFolder':
              return selected ? {'uri': 'content://tree/test', 'name': 'test'} : null;
            case 'pickFolder':
              selected = true;
              return {'uri': 'content://tree/test', 'name': 'test'};
            case 'list':
              return [
                {'name': 'lib', 'directory': true, 'size': 0, 'path': 'lib'},
              ];
            case 'read':
              final path = (call.arguments as Map)['path'] as String;
              return storedFiles[path] ?? 'void main() {}';
            case 'write':
              final args = call.arguments as Map;
              storedFiles[args['path'] as String] = args['content'] as String;
              return true;
            case 'mkdir':
            case 'rename':
            case 'move':
            case 'duplicate':
            case 'delete':
            case 'clearFolder':
              return true;
            default:
              throw MissingPluginException();
          }
        });
  });

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, null);
  });

  test('project file actions require the agent tool, not a prose answer', () {
    expect(ProjectFolderService.requiresToolForRequest('Check the files in my project.'), isTrue);
    expect(ProjectFolderService.requiresToolForRequest('List the files in the selected folder.'), isTrue);
    expect(ProjectFolderService.requiresToolForRequest('Create README.md in my project.'), isTrue);
    expect(ProjectFolderService.requiresToolForRequest('Hi bro, make a tiny Python file in the folder.'), isTrue);
    expect(ProjectFolderService.requiresToolForRequest('Make a small hello.py here.'), isTrue);
    expect(ProjectFolderService.requiresToolForRequest('Read README.md.'), isTrue);
    expect(ProjectFolderService.requiresToolForRequest('Update pubspec.yaml.'), isTrue);
    expect(ProjectFolderService.requiresToolForRequest('Attach the main source file from my repository.'), isTrue);
    expect(ProjectFolderService.requiresToolForRequest('Check your new tools.'), isTrue);
    expect(ProjectFolderService.requiresToolForRequest('How do I list files in my project?'), isFalse);
    expect(ProjectFolderService.requiresToolForRequest('Explain how to edit source code.'), isFalse);
    expect(ProjectFolderService.requiresToolForRequest('Hello, how are you?'), isFalse);
  });

  test('casual tiny Python file request gets a safe selected-folder write call', () {
    final call = ProjectFolderService.simplePythonCreateCall(
      'Hi bro, make a tiny Python file in the folder!',
    );
    expect(call?.name, 'project_write_file');
    expect(call?.args, {
      'path': 'hello.py',
      'content': 'print("Hello, world!")\n',
    });
    expect(
      ProjectFolderService.simplePythonCreateCall('Explain how to make a tiny Python file in the folder.'),
      isNull,
    );
  });

  test('project tools stay unavailable until a folder is selected', () async {
    final service = ProjectFolderService();
    await service.load();
    expect(service.isSelected, isFalse);
    expect(service.specs, isEmpty);
    service.dispose();
  });

  test('selected folder exposes bounded relative-path agent tools', () async {
    final service = ProjectFolderService();
    await service.selectFolder();
    expect(service.folder?['name'], 'test');
    expect(service.specs.map((e) => e.name).toSet(), {
      'project_list_files',
      'project_read_file',
      'project_write_file',
      'project_create_folder',
      'project_rename',
      'project_move',
      'project_duplicate',
      'project_search_contents',
      'project_get_metadata',
      'project_attach_file',
      'project_delete',
    });
    final result = await service.call(const ToolCall(
      id: '1', name: 'project_read_file', arguments: '{"path":"lib/main.dart"}',
    ), expectedUri: 'content://tree/test');
    expect(result.ok, isTrue);
    expect(result.output, 'void main() {}');
    expect(calls.map((e) => e.method), contains('read'));
    final moved = await service.call(const ToolCall(
      id: '2', name: 'project_move',
      arguments: '{"source_path":"src/old.dart","destination_path":"lib/old.dart"}',
    ), expectedUri: 'content://tree/test');
    expect(moved.ok, isTrue);
    final deleted = await service.call(const ToolCall(
      id: '3', name: 'project_delete', arguments: '{"path":"build/cache"}',
    ), expectedUri: 'content://tree/test');
    expect(deleted.ok, isTrue);
    expect(calls.map((e) => e.method), containsAll(['move', 'delete']));
    service.dispose();
  });
  test('project_root is normalized to the selected folder root for listings', () async {
    final service = ProjectFolderService();
    await service.selectFolder();
    final result = await service.call(
      const ToolCall(
        id: 'root-alias',
        name: 'project_list_files',
        arguments: '{"path":"project_root"}',
      ),
      expectedUri: 'content://tree/test',
    );
    expect(result.ok, isTrue);
    final listCall = calls.lastWhere((call) => call.method == 'list');
    expect((listCall.arguments as Map)['path'], '');
    service.dispose();
  });

  test('every advertised project tool dispatches to its matching SAF method', () async {
    final service = ProjectFolderService();
    await service.selectFolder();
    const uri = 'content://tree/test';
    final cases = <(String, String, String)>[
      ('project_list_files', '{"path":""}', 'list'),
      ('project_read_file', '{"path":"README.md"}', 'read'),
      ('project_write_file', '{"path":"README.md","content":"hello"}', 'write'),
      ('project_create_folder', '{"path":"src/new"}', 'mkdir'),
      ('project_rename', '{"path":"old.txt","name":"new.txt"}', 'rename'),
      ('project_move', '{"source_path":"old.txt","destination_path":"archive/old.txt"}', 'move'),
      ('project_duplicate', '{"source_path":"old.txt","destination_path":"copy/old.txt"}', 'duplicate'),
      ('project_search_contents', '{"query":"main"}', 'list'),
      ('project_get_metadata', '{"path":"lib"}', 'list'),
      ('project_delete', '{"path":"cache"}', 'delete'),
    ];
    for (var i = 0; i < cases.length; i++) {
      final (name, arguments, method) = cases[i];
      final result = await service.call(
        ToolCall(id: 'all-$i', name: name, arguments: arguments),
        expectedUri: uri,
      );
      expect(result.ok, isTrue, reason: '$name should execute successfully');
      expect(calls.map((call) => call.method), contains(method), reason: '$name must call $method');
    }
    service.dispose();
  });

  test('model-facing project tools cannot overwrite runtime-owned memory', () async {
    final service = ProjectFolderService();
    await service.selectFolder();
    final before = calls.length;
    final result = await service.call(const ToolCall(
      id: 'memory-write',
      name: 'project_write_file',
      arguments: '{"path":".ai_memory/task_state.txt","content":"fake success"}',
    ), expectedUri: 'content://tree/test');
    expect(result.ok, isFalse);
    expect(result.output, contains('reserved'));
    expect(calls.length, before, reason: 'Protected memory paths must never reach SAF.');
    service.dispose();
  });

  test('project tool calls fail closed if the selected folder changes', () async {
    final service = ProjectFolderService();
    await service.selectFolder();
    final before = calls.length;
    final result = await service.call(const ToolCall(
      id: 'stale',
      name: 'project_read_file',
      arguments: '{"path":"README.md"}',
    ), expectedUri: 'content://tree/another-folder');
    expect(result.ok, isFalse);
    expect(result.output, contains('changed during this task'));
    expect(calls.length, before, reason: 'A stale call must not reach the SAF bridge.');
    service.dispose();
  });

  test('project service rejects paths that could escape the selected tree', () async {
    final service = ProjectFolderService();
    await service.selectFolder();
    final before = calls.length;
    expect(() => service.read('../outside.txt'), throwsFormatException);
    expect(() => service.read('/storage/emulated/0/private.txt'), throwsFormatException);
    expect(() => service.move('src/a', r'..\outside\a'), throwsFormatException);
    expect(() => service.delete(''), throwsFormatException);
    expect(calls.length, before, reason: 'Invalid paths must be rejected before reaching Android.');
    service.dispose();
  });

}
