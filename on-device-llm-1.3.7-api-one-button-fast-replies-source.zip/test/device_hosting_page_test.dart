import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ondevice_llm/core/theme/app_theme.dart';
import 'package:ondevice_llm/features/hosting/presentation/device_hosting_page.dart';
import 'package:ondevice_llm/features/hosting/presentation/device_hosting_provider.dart';
import 'package:ondevice_llm/features/models/presentation/providers/model_manager_provider.dart';
import 'package:ondevice_llm/features/settings/presentation/providers/settings_provider.dart';

import 'advanced_pages_2_test.dart' show TestModels, TestSettings;

class RunningHost extends DeviceHostingNotifier {
  @override
  DeviceHostingState build() => const DeviceHostingState(
    running: true,
    endpoint: 'http://192.168.1.5:8787/v1/',
    token: 'abcdefghijklmnopqrstuvwxyz012345',
    modelId: 'test-model',
  );
}

Widget harness({bool running = false}) => ProviderScope(
  overrides: [
    settingsProvider.overrideWith(TestSettings.new),
    modelManagerProvider.overrideWith(TestModels.new),
    if (running) deviceHostingProvider.overrideWith(RunningHost.new),
  ],
  child: MaterialApp(theme: AppTheme.dark, home: const DeviceHostingPage()),
);

void main() {
  testWidgets('setup exposes one start control and no manual port settings', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(360, 1200);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    await tester.pumpWidget(harness());
    await tester.pump();

    expect(find.byKey(const Key('host-start-stop')), findsOneWidget);
    expect(find.text('Start server'), findsOneWidget);
    expect(find.byType(TextField), findsNothing);
    expect(find.textContaining('currently loaded model'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('running shows copyable OpenAI client connection values', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(360, 1400);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    await tester.pumpWidget(harness(running: true));
    await tester.pump();

    expect(find.byKey(const Key('host-start-stop')), findsOneWidget);
    expect(find.text('Stop server'), findsOneWidget);
    expect(find.text('http://192.168.1.5:8787/v1/'), findsOneWidget);
    expect(find.text('test-model'), findsNWidgets(2));
    expect(find.text('•••••••• 2345'), findsOneWidget);
    expect(find.byKey(const Key('copy-api-setup')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
