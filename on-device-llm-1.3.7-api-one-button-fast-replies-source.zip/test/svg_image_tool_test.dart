import 'package:flutter_test/flutter_test.dart';
import 'package:ondevice_llm/features/tools/svg_image_tool.dart';

void main() {
  test('accepts a self-contained vector with paths, gradients and groups', () {
    const svg = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
      <defs><linearGradient id="g"><stop offset="0" stop-color="#fff"/><stop offset="1" stop-color="#000"/></linearGradient></defs>
      <g opacity="0.9" transform="translate(2 2)"><path d="M 2 2 C 20 0 80 100 98 98 Z" fill="url(#g)"/></g>
    </svg>''';
    expect(SvgImageTool.validate(svg), contains('<svg'));
  });

  test('rejects script, event handlers and external references', () {
    expect(
      () => SvgImageTool.validate('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>'),
      throwsFormatException,
    );
    expect(
      () => SvgImageTool.validate('<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)"/>'),
      throwsFormatException,
    );
    expect(
      () => SvgImageTool.validate('<svg xmlns="http://www.w3.org/2000/svg"><use href="https://example.com/a.svg"/></svg>'),
      throwsFormatException,
    );
  });

  test('accepts valid local references and rejects broken or duplicate ids', () {
    const valid = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
      <defs><linearGradient id="sky"><stop offset="0" stop-color="#fff"/></linearGradient>
        <path id="shape" d="M0 0 L10 10"/>
      </defs>
      <rect width="100" height="100" fill="url(#sky)"/>
      <use href="#shape"/>
    </svg>''';
    expect(SvgImageTool.validate(valid), contains('url(#sky)'));
    expect(
      () => SvgImageTool.validate('<svg xmlns="http://www.w3.org/2000/svg"><use href="#missing"/></svg>'),
      throwsFormatException,
    );
    expect(
      () => SvgImageTool.validate('<svg xmlns="http://www.w3.org/2000/svg"><g id="same"/><path id="same" d="M0 0"/></svg>'),
      throwsFormatException,
    );
  });

  test('rejects unsupported foreign content and document types', () {
    expect(
      () => SvgImageTool.validate('<!DOCTYPE svg><svg xmlns="http://www.w3.org/2000/svg"/>'),
      throwsFormatException,
    );
    expect(
      () => SvgImageTool.validate('<svg xmlns="http://www.w3.org/2000/svg"><foreignObject/></svg>'),
      throwsFormatException,
    );
  });
}
