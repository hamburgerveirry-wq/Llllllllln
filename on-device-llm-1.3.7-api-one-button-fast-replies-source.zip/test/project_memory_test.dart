import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ondevice_llm/features/tools/project_folder.dart';
import 'package:ondevice_llm/features/tools/project_memory.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const channel = MethodChannel('ondevice_llm/project_folder');
  final files = <String, String>{};
  final calls = <MethodCall>[];

  setUp(() {
    files.clear();
    calls.clear();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (call) async {
          calls.add(call);
          switch (call.method) {
            case 'pickFolder':
              return {'uri': 'content://tree/memory-test', 'name': 'memory-test'};
            case 'mkdir':
              return true;
            case 'write':
              final args = Map<String, Object?>.from(call.arguments as Map);
              files[args['path']! as String] = args['content']! as String;
              return true;
            case 'read':
              final path = (call.arguments as Map)['path'] as String;
              if (!files.containsKey(path)) {
                throw PlatformException(code: 'PROJECT_FOLDER', message: 'File missing.');
              }
              return files[path];
            case 'list':
              return [
                {'name': 'lib', 'directory': true, 'size': 0, 'path': 'lib'},
                {'name': 'pubspec.yaml', 'directory': false, 'size': 120, 'path': 'pubspec.yaml'},
              ];
            default:
              throw MissingPluginException();
          }
        });
  });

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, null);
  });

  test('creates the five memory files and checkpoints original request/status', () async {
    final folder = ProjectFolderService();
    await folder.selectFolder();
    final memory = ProjectMemoryStore(folder);
    await memory.beginTask('Always preserve the original build constraints.');
    await memory.preserveExplicitInstruction('Always preserve the original build constraints.');
    final context = await memory.loadCoreContext();
    expect(context, contains('Current task'));
    await memory.finishTask(
      originalRequest: 'Always preserve the original build constraints.',
      answer: 'The task was interrupted before verification.',
      status: 'interrupted',
    );
    expect(files.keys.toSet(), {
      '.ai_memory/memory.txt',
      '.ai_memory/agent_context.txt',
      '.ai_memory/task_state.txt',
      '.ai_memory/project_knowledge.txt',
      '.ai_memory/recovery.txt',
    });
    expect(files['.ai_memory/memory.txt'], contains('Always preserve'));
    expect(files['.ai_memory/task_state.txt'], contains('Status: interrupted'));
    expect(files['.ai_memory/recovery.txt'], contains('original request'));
    expect(calls.any((c) => c.method == 'list'), isTrue);
    folder.dispose();
  });
}
